import os
import sys
import traceback


def selftest() -> int:
    """Headless smoke test (used by the CI on the packaged app): imports everything, builds the main
    window with the offscreen Qt platform and checks that the bundled R files are present."""
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    import core_calcolo as engine
    from PySide6.QtWidgets import QApplication
    app = QApplication([])              # must exist before matplotlib selects its Qt backend (headless CI)
    import gui_qt
    import heatmap_window_qt, report_pdf, gene_plots, pca_coloring  # noqa: F401
    from qt_theme import apply_theme
    apply_theme(app)
    win = gui_qt.DEAWindow()
    win.show()
    missing = [p for p in (engine.CORE_R_PATH, engine.RUNNER_R_PATH) if not p.exists()]
    if missing:
        print("SELFTEST FAILED, missing bundled files:", *missing)
        return 1
    print("SELFTEST OK | resources:", engine.resource_dir(), "| Rscript:", engine.find_rscript())
    return 0


def main():
    if "--selftest" in sys.argv:
        sys.exit(selftest())

    try:
        import core_calcolo as engine
    except Exception as e:
        print("Critical error: unable to import core_calcolo.py:", e)
        traceback.print_exc()
        sys.exit(1)

    problems = engine.check_environment()
    if problems:
        print("Attention: the following environmental issues have been detected:")
        for p in problems:
            print(" - " + p)
        print("The app will launch anyway; you can correct the environment and try again from the GUI.\n")

    try:
        import gui_qt as gui
    except Exception as e:
        print("Critical error: unable to import gui_qt.py:", e)
        print("Verify that the Python dependencies are installed: run ./setup_mac.sh "
              "(or: pip install -r requirements.txt).")
        traceback.print_exc()
        sys.exit(1)

    gui.launch()


if __name__ == "__main__":
    main()
