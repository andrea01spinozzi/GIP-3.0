# PyInstaller spec -> "DEA Explorer.app" on macOS (onedir bundle, no console window).
# Build:  pyinstaller --noconfirm packaging/DEA_Explorer.spec
import os
from pathlib import Path

ROOT = Path(SPECPATH).parent
VERSION = os.environ.get("APP_VERSION", "0.0.0")
ICON = ROOT / "assets" / "icon.icns"

a = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT)],
    datas=[
        (str(ROOT / "DE_scheletro_FINALE.Rmd"), "."),
        (str(ROOT / "run_pipeline.R"), "."),
        (str(ROOT / "install_r_packages.R"), "."),
        (str(ROOT / "logo.png"), "."),
    ],
    hiddenimports=[
        "core_calcolo", "gui_qt", "heatmap_window_qt", "report_pdf", "gene_plots", "pca_coloring",
        "qt_theme", "qt_plots", "qt_models", "help_content",
        "matplotlib.backends.backend_qtagg", "matplotlib.backends.backend_pdf",
        "openpyxl", "xlrd", "mplcursors", "scipy.stats",
    ],
    excludes=[
        "tkinter", "PyQt5", "PyQt6", "PySide2", "IPython", "jupyter", "notebook", "pytest",
        "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtWebEngineQuick",
        "PySide6.QtQuick", "PySide6.QtQml", "PySide6.Qt3DCore", "PySide6.QtMultimedia",
        "PySide6.QtCharts", "PySide6.QtDataVisualization", "PySide6.QtPdf", "PySide6.QtPdfWidgets",
    ],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="DEA Explorer",
    console=False,
    icon=str(ICON) if ICON.exists() else None,
    target_arch=None,               # build for the architecture of the runner (arm64 or x86_64)
)

coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="DEA Explorer")

app = BUNDLE(
    coll,
    name="DEA Explorer.app",
    icon=str(ICON) if ICON.exists() else None,
    bundle_identifier="org.deaexplorer.app",
    version=VERSION,
    info_plist={
        "CFBundleName": "DEA Explorer",
        "CFBundleDisplayName": "DEA Explorer",
        "CFBundleShortVersionString": VERSION,
        "LSMinimumSystemVersion": "11.0",
        "NSHighResolutionCapable": True,
        "NSRequiresAquaSystemAppearance": False,
        "LSApplicationCategoryType": "public.app-category.education",
    },
)
