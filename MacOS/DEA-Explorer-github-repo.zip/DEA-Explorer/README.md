# DEA Explorer

Desktop app for Differential Expression Analysis (DESeq2 / limma), over-representation (ORA) and GSEA,
with PCA, volcano plots, heatmaps and PDF reports. GUI in Python (PySide6), statistics in R.

## For users (macOS 11 or newer)

1. **Install R** (once): https://cran.r-project.org/bin/macosx/ — pick the *arm64* build on M-series Macs,
   the *Intel* build otherwise. Then run in Terminal: `xcode-select --install`.
2. **Install the R packages** (once, 15–40 min):
   ```bash
   Rscript -e 'source("https://raw.githubusercontent.com/OWNER/REPO/main/install_r_packages.R")'
   ```
   The same script is bundled in the repository (`install_r_packages.R`). For mouse/rat/zebrafish annotation run
   `Rscript install_r_packages.R mouse rat zebrafish` from a clone of the repository.
3. **Download the app** from the [Releases page](../../releases/latest):
   `DEA-Explorer-<version>-macOS-arm64.dmg` for Apple Silicon (M1–M4) or `…-x86_64.dmg` for Intel Macs
   (Apple menu → About This Mac shows which one you have).
4. Open the `.dmg` and drag **DEA Explorer** into **Applications**.
5. **First launch.** The app is not signed with a paid Apple Developer ID, so macOS blocks it the first time:
   - try to open it, then go to **System Settings → Privacy & Security**, scroll down and click **Open Anyway**; or
   - run once in Terminal: `xattr -dr com.apple.quarantine "/Applications/DEA Explorer.app"`

If the app says *Rscript not found*, R is not installed or lives in a custom folder; start the app from Terminal with
`DEA_RSCRIPT=/full/path/to/Rscript open -a "DEA Explorer"`.

## For the maintainer: publishing on GitHub

```bash
cd DEA-Explorer
git init && git add . && git commit -m "DEA Explorer"
git branch -M main
git remote add origin https://github.com/OWNER/REPO.git
git push -u origin main
```
Replace `OWNER/REPO` in this README (step 2) with your repository path, commit, and then publish a version:
```bash
git tag v1.0.0 && git push --tags
```
GitHub Actions (`.github/workflows/build-macos.yml`) builds the app on macOS runners for **Apple Silicon and Intel**,
runs a headless smoke test on each packaged app, and attaches both `.dmg` files to a new Release (~10–15 min).
You can also run the workflow manually from the **Actions** tab; the `.dmg` files are then available as run artifacts.

Notes
- The `.app` is built by CI because macOS apps can only be built on macOS. Locally (on a Mac):
  `pip install -r requirements.txt pyinstaller && pyinstaller --noconfirm packaging/DEA_Explorer.spec`.
- R and the R packages are **not** bundled (Bioconductor is several GB); every user installs them once as above.
- To remove the "Open Anyway" step you need an Apple Developer ID (99 USD/year) to sign and notarize the app.
- Add a `LICENSE` file before making the repository public.
- Run from source without packaging: `./setup_mac.sh`, then `./run_mac.command`.
