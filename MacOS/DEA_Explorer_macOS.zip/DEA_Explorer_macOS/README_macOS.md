# DEA Explorer – macOS edition

Works on macOS 11+ (Intel and Apple Silicon).

## Install (once)
1. Install **Python 3.9+** (python.org or `brew install python`) and **R** (https://cran.r-project.org/bin/macosx/ –
   choose the *arm64* build on M1/M2/M3/M4 Macs). Run `xcode-select --install` in Terminal if you have never done it.
2. Unzip this folder anywhere, e.g. in your home folder.
3. Open **Terminal**, then:
   ```
   cd path/to/DEA_Explorer_macOS
   xattr -dr com.apple.quarantine .      # removes the "downloaded from the internet" block
   chmod +x setup_mac.sh run_mac.command
   ./setup_mac.sh
   ```
   This creates a private Python environment (`.venv`) and installs the R packages
   (DESeq2, clusterProfiler, fgsea, limma, ...). For mouse/rat/zebrafish data:
   `Rscript install_r_packages.R mouse rat zebrafish`.

## Run
Double-click **run_mac.command** (or `./run_mac.command`). If macOS refuses to open it:
right-click → Open → Open, once.

## What was changed compared with the Windows version
- `core_calcolo.py`: Rscript is searched in the macOS locations (CRAN framework, Homebrew Apple Silicon/Intel,
  MacPorts, conda) – needed because apps started from Finder don't see your shell PATH. Custom location:
  `DEA_RSCRIPT=/path/to/Rscript ./run_mac.command`. R now runs with a UTF-8 locale and output is read as UTF-8.
- `run_pipeline.R`: the core is parsed as UTF-8 regardless of the locale.
- `qt_theme.py`: macOS fonts (Helvetica Neue / Menlo) and automatic font-size scaling (Qt uses 72 DPI on macOS,
  so Windows point sizes would look ~25% too small).
- `gui_qt.py` / `heatmap_window_qt.py`: shortcuts show ⌘ instead of Ctrl. **Heatmap = ⌘⇧H** (⌘H is "Hide" in macOS).
  Heatmap zoom on samples: hold ⌘ or Control while scrolling.
- `qt_plots.py`: matplotlib font list includes macOS fonts.
- Files renamed to the names the code expects: `DE_scheletro_FINALE.Rmd`, `run_pipeline.R`.
- Windows demo paths in the `.Rmd` (section 7, never executed by the app) replaced with portable ones.
- New: `requirements.txt`, `setup_mac.sh`, `run_mac.command`, `install_r_packages.R`.

## Troubleshooting
- "Rscript not found" at start: install R, or set `DEA_RSCRIPT`.
- R package error: run `Rscript install_r_packages.R` again and read the last lines for the failing package.
- Optional logo: put `logo.png` next to `main.py` for the Dock/window icon.
