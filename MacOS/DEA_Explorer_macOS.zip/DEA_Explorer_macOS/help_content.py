from typing import Any, Dict, List, Optional, Tuple

# Palette di colori accessibile (Okabe-Ito)
OKABE_ITO: List[str] = [
    "#E69F00",  # Arancione
    "#56B4E9",  # Celeste
    "#009E73",  # Verde acqua
    "#F0E442",  # Giallo
    "#0072B2",  # Blu
    "#D55E00",  # Rosso vermiglio
    "#CC79A7",  # Rosa magenta
    "#000000",  # Nero
]

# Posizioni supportate per le legende nei grafici
LEGEND_POSITIONS: List[str] = [
    "best",
    "upper right",
    "upper left",
    "lower left",
    "lower right",
    "center left",
    "center right",
    "upper center",
    "lower center",
    "outside",
]

# Preset per le dimensioni di esportazione delle figure (larghezza, altezza in pollici)
EXPORT_PRESETS: Dict[str, Optional[Tuple[float, float]]] = {
    "Custom": None,
    "Single column (89 mm)": (89 / 25.4, (89 / 25.4) * 0.75),
    "1.5 column (140 mm)": (140 / 25.4, (140 / 25.4) * 0.62),
    "Double column (183 mm)": (183 / 25.4, (183 / 25.4) * 0.5),
    "Square 10x10 cm": (10 / 2.54, 10 / 2.54),
    "Slide 16:9 (25.4x14.3 cm)": (10.0, 5.63),
}

# Testi di aiuto e documentazione per l'interfaccia utente
HELP_CONTENT: Dict[str, Dict[str, str]] = {
    "setup": {
        "title": "Help — Setup & Parameters",
        "meaning": (
            "This tab prepares the Differential Expression Analysis (DEA): the "
            "statistical comparison of expression levels for each gene between two "
            "conditions (e.g. 'Treated' vs 'Control', or 'Responder' vs 'Non-responder').\n\n"
            "What you need:\n"
            "- The COUNTS file: a gene (rows) x sample (columns) table. For RNA-seq "
            "these must be raw counts (integers, e.g. the number of reads aligned to "
            "each gene), NOT already normalized values (TPM/FPKM), because DESeq2 "
            "applies its own statistical normalization.\n"
            "- The METADATA file: a table linking each sample (same ID column as the "
            "counts) to its experimental condition (e.g. treatment group).\n\n"
            "Statistical method:\n"
            "- DESeq2 (Wald test): models counts with a negative binomial "
            "distribution, suited to the typical noise of sequencing data (variance "
            "growing faster than the mean). It is the correct choice for raw RNA-seq counts.\n"
            "- limma (eBayes): designed for continuous, already log-transformed "
            "intensity data such as microarrays; it uses Bayesian moderation of "
            "variance to stabilize the estimate when there are few samples per group.\n\n"
            "Parameters:\n"
            "- padj cutoff: threshold on the multiple-testing CORRECTED p-value "
            "(typically via the Benjamini-Hochberg/FDR method). It is needed because "
            "when testing thousands of genes in parallel, some small p-values would "
            "arise purely by chance: padj keeps the expected proportion of false "
            "positives under control. Example: with padj<0.05 you accept that, on "
            "average, 5% of genes declared significant might not really be so.\n"
            "- log2FoldChange cutoff: threshold on the magnitude of change. log2FC=1 "
            "corresponds to a doubling of expression; log2FC=-1 to a halving. A gene "
            "can be statistically significant but with a biologically negligible "
            "change: this cutoff is used to discard those cases.\n"
            "- MSigDB category (for the subsequent GSEA): 'H' (Hallmark) groups a few "
            "dozen well-characterized and coherent gene sets (e.g. the KRAS signaling "
            "pathway, EMT, inflammatory response); other categories (C2 = curated "
            "pathways such as KEGG/Reactome, C5 = Gene Ontology, etc.) are more "
            "granular or specific.\n"
            "- ORA (Over-Representation Analysis): runs alongside the GSEA, with the "
            "same MSigDB category and the same padj / log2FC cutoffs. You can turn it "
            "off and choose which genes it uses: all DEGs (up + down), only "
            "up-regulated or only down-regulated ones."
        ),
        "usage": (
            "1. Press 'Browse...' to select the counts file and the metadata file "
            "(accepts csv/tsv/txt/xlsx/xls/json).\n"
            "2. Check/correct the column indices or names (genes, samples, "
            "condition): you can enter either a number (1 = first column) or the "
            "exact column name.\n"
            "3. Choose the correct statistical method based on the data type "
            "(RNA-seq -> DESeq2, microarray -> limma).\n"
            "4. Press 'Extract groups from metadata': the list of conditions found "
            "will appear, with the corresponding number of samples (n=...).\n"
            "5. Check EXACTLY 2 groups to compare, or enable the 'Compare ALL pairs "
            "of groups (pairwise)' checkbox if you want all possible contrasts at "
            "once (in that case the individual group checkboxes are disabled).\n"
            "6. Set the padj cutoff, log2FC cutoff, and MSigDB category for the "
            "GSEA and ORA (tick/untick 'Run ORA' and pick which genes it should use).\n"
            "7. The 'Preparation status' panel at the top and the red borders on "
            "required fields show you what is still missing; the 'Run analysis' "
            "button is enabled only once both counts and metadata have been selected.\n"
            "8. Press 'Run analysis': the progress bar and timer show that the "
            "computation (DESeq2/limma + GSEA in R) is running; when finished you "
            "are automatically switched to the PCA tab.\n"
            "9. 'Reset fields' clears the whole file/columns/groups section so you "
            "can start over.\n"
            "10. Once the analysis has finished, 'Download PDF report' saves a "
            "detailed report (parameters, PCA, volcano plot, top DEGs, GSEA, ORA "
            "and the processing log for every contrast) as a PDF file."
        ),
    },
    "pca": {
        "title": "Help — PCA",
        "meaning": (
            "PCA (Principal Component Analysis) is a statistical technique that "
            "reduces the thousands of genes measured for each sample to a few "
            "'principal components' (PC1, PC2, ...), linear combinations of genes "
            "chosen to capture as much of the data's variability as possible in the "
            "fewest dimensions.\n\n"
            "In practice: each point in the chart is a sample (not a gene). If two "
            "samples have a similar expression profile, their points will be close; "
            "if they are very different, they will be far apart. PC1 and PC2 report "
            "in parentheses the percentage of total variance they manage to explain: "
            "the higher it is, the more faithfully that 2D chart represents the true "
            "differences between samples (rather than losing information by "
            "compressing too many dimensions into two).\n\n"
            "Biological purpose: to check whether samples group according to the "
            "expected experimental condition (e.g. all 'responders' close together, "
            "separated from 'non-responders'). If instead the groups do not "
            "separate, or a sample is isolated far from all the others, this can "
            "indicate: a batch effect (samples processed on different days/batches), "
            "a low-quality sample, or simply that condition has no strong "
            "transcriptomic effect."
        ),
        "usage": (
            "- 'Color by': colors the points by any column of the metadata file "
            "(age, tumor stage, sex, treatment...). Numeric columns get a continuous "
            "color scale with a color bar; text columns get one distinct color per "
            "group, with a legend. Missing values are grey. Use 'Type' to force "
            "numeric/categorical and 'Scale' to choose the numeric color scale.\n"
            "- 'Show sample labels': writes the ID of each sample next to its point.\n"
            "- 'Confidence ellipses per group': draws an ellipse around the samples "
            "of each condition (requires at least 3 samples per group) to better "
            "visualize separation.\n"
            "- 'Color-blind-friendly palette': switches the group colors to the "
            "Okabe-Ito palette, readable even by people with color vision deficiencies.\n"
            "- 'Custom title' + 'Apply': replaces the chart's automatic title.\n"
            "- Zoom/pan: use the matplotlib toolbar above the chart (the "
            "magnifying glass and the hand) to zoom into an area or move around.\n\n"
            "How to add manual annotations (arrows, lines, boxes, text):\n"
            "1. In the 'Manual annotations' bar, choose the tool: Arrow, Line, Box "
            "or Text (or 'None' to disable).\n"
            "2. For Arrow/Line/Box: click on the chart at the starting point and "
            "drag to the end point, then release the mouse button.\n"
            "3. For Text: simply click where you want the text, then type the "
            "content in the window that appears.\n"
            "4. You can change color (colored button next to 'Color') and line "
            "width before drawing the next annotation.\n"
            "5. 'Undo last' removes only the last annotation added; 'Clear all' "
            "removes all of them.\n"
            "Note: if you change an option that redraws the chart from scratch "
            "(e.g. enabling/disabling ellipses), manual annotations are cleared: add "
            "them last, once the chart is already set up.\n\n"
            "To export the figure in high resolution (for a paper/poster): press "
            "'Export image', choose a size preset (single/1.5/double column), the "
            "file format (PDF/SVG/EPS are vector formats, ideal for crisp text and "
            "lines; PNG/TIFF are raster), the DPI (300 is the minimum standard "
            "required by most journals) and press 'Save...'."
        ),
    },
    "volcano": {
        "title": "Help — Volcano Plot",
        "meaning": (
            "The volcano plot combines, for each gene, TWO pieces of information at "
            "the same time: how much its expression changed (X axis) and how "
            "statistically reliable that change is (Y axis).\n\n"
            "- X axis = log2FoldChange: expression change between the two "
            "conditions on a log2 scale. Example: log2FC = 2 means the gene is "
            'expressed 4 times more (2^2) in the FIRST group of the contrast ("A" in '
            '"A vs B"; B is the reference/denominator); log2FC = -1 means '
            "expression in A is half of that in B.\n"
            "- Y axis = -log10(padj): the HIGHER a point is, the lower (hence more "
            "significant) its padj is. -log10 is used only to make very small "
            "p-values readable on a chart (e.g. padj = 0.00001 becomes 5 on the Y axis).\n\n"
            "The dashed horizontal and vertical lines mark the cutoffs chosen in the "
            "Setup tab: a gene is colored as 'Upregulated' or 'Downregulated' only if "
            "it passes BOTH thresholds (significance AND effect size); otherwise it "
            "stays gray ('Not Significant'). The typical 'butterfly/volcano' shape of "
            "the chart arises because genes with more extreme changes (tails on the "
            "right/left) also tend to be the most significant (points higher up), "
            "hence the name."
        ),
        "usage": (
            "- 'Contrast': if you ran multiple comparisons (e.g. with the pairwise "
            "option), choose here which one to display.\n"
            "- Gene labels: choose the mode ('None', 'All significant genes', 'Top N "
            "by padj', 'Top N by |log2FC|', 'Specific genes (list)'). With 'Specific "
            "genes' type the names separated by commas in the field below (e.g. "
            "TP53, MYC, EGFR). Adjust 'Top N' and 'Font size' as needed; 'Leader "
            "lines to label' helps readability when there are many labels close together.\n"
            "- Appearance: customize the Up/Down/NS color (click the colored "
            "square), point size and transparency, and the title.\n"
            "- After changing a setting, press 'Apply changes' to regenerate the "
            "chart (there is no need to rerun the whole analysis in R).\n\n"
            "Manual annotations (arrows/lines/boxes/text): same procedure described "
            "for PCA — choose the tool in the 'Manual annotations' bar, drag (or "
            "click for text) directly on the chart. Remember: pressing 'Apply "
            "changes' redraws the chart and clears manual annotations, so add them last.\n\n"
            "For high-resolution export, use 'Export image' as in the PCA tab."
        ),
    },
    "table": {
        "title": "Help — Gene Table",
        "meaning": (
            "This tab shows, in tabular form, the same statistical results as the "
            "volcano plot: a complete (or filtered) list of genes with the values "
            "produced by DESeq2/limma.\n\n"
            "Columns:\n"
            "- GeneID: gene identifier (symbol, e.g. KRAS, or Ensembl ID if the "
            "symbol is not available).\n"
            "- Regulation: states in which group the gene is higher "
            '("Higher in A" / "Higher in B") when it passes the padj AND log2FC '
            'cutoffs set in the Setup tab; otherwise "Not significant". '
            "The group names are those of the active contrast.\n"
            "- Significant: indicates whether the gene passes BOTH the padj cutoff "
            "AND the log2FC cutoff set in the Setup tab (i.e. whether it is colored "
            "in the volcano plot).\n"
            "- log2FoldChange: the magnitude of the change on a log2 scale (see the "
            "Volcano Plot help for details).\n"
            "- pvalue: the 'raw' statistical significance, BEFORE multiple-testing correction.\n"
            "- padj: the corrected p-value (e.g. Benjamini-Hochberg/FDR method): "
            "this is the value to use to decide whether a gene is significant, "
            "never the raw pvalue, because testing thousands of genes together "
            "would underestimate the false positive rate.\n"
            "- stat: the test statistic (e.g. the Wald statistic for DESeq2, "
            "moderated t for limma) from which the pvalue is derived; the sign "
            "indicates direction, the absolute value the strength of the signal."
        ),
        "usage": (
            "- 'Filter (search GeneID)': type even part of a gene name to filter "
            "the table in real time (e.g. typing 'KRAS' also shows any related "
            "genes containing that string).\n"
            "- Regulation dropdown: shows only genes higher in the first group, "
            "only genes higher in the second (reference) group, or only "
            "Not significant ones.\n"
            "- Click a column header (e.g. 'padj') to sort the table by that "
            "column; click again to reverse ascending/descending order.\n"
            "- 'Export CSV...': saves the currently filtered/sorted table to a CSV "
            "file, useful for further analysis in Excel/R/Python or as "
            "supplementary material for a paper.\n"
            "- The number in the bottom right ('N genes shown') updates based on "
            "the applied filters."
        ),
    },
    "gsea": {
        "title": "Help — GSEA / Pathway",
        "meaning": (
            "GSEA (Gene Set Enrichment Analysis) answers a different question than "
            "the single-gene one: instead of asking 'did this gene change "
            "significantly?', it asks 'does an entire group of genes belonging to "
            "the same biological pathway move coherently in one direction, even if "
            "each individual gene on its own is not strong enough to be significant?'.\n\n"
            "How it works, briefly: all genes are ranked based on a statistic "
            "derived from the comparison between the two conditions; for each gene "
            "set (e.g. 'HALLMARK_KRAS_SIGNALING', a group of genes typically "
            "activated/modulated when the KRAS signaling pathway is hyperactive) it "
            "is checked whether its genes cluster unusually toward the top or "
            "bottom of this ranking, compared to what would be expected by pure chance.\n\n"
            "- NES (Normalized Enrichment Score): the enrichment score, normalized "
            "for gene set size (so pathways with more or fewer genes are "
            "comparable). Positive NES = the gene set is shifted toward the most "
            'genes higher in the FIRST group of the contrast ("A" in "A vs B"); '
            "negative NES = toward the genes higher in the SECOND group (the reference).\n"
            "- padj: as for single genes, this is the enrichment p-value corrected "
            "for the number of gene sets tested together.\n"
            "- Asterisks (*, **, ***) indicate padj<0.05, <0.01, <0.001 "
            "respectively, following the most common graphical convention in publications.\n\n"
            "Important point: a significant NES does NOT imply that the individual "
            "genes of that pathway are significant DEGs one by one (nor that they "
            "are mutated); it means that the overall pathway pattern, summed over "
            "many genes that agree even if weak individually, is statistically robust."
        ),
        "usage": (
            "- 'Top N pathways': how many pathways to show in the bar chart (in "
            "order of significance/|NES|).\n"
            "- 'Significance asterisks': show/hide the * ** *** symbols next to each bar.\n"
            "- 'Custom title' + 'Apply': replaces the automatic title.\n"
            "- 'Export pathway table CSV...': saves the full list of pathways "
            "shown (name, NES, padj, gene set size) to a CSV file.\n"
            "- The table at the bottom shows the same data as the chart; click "
            "the headers to sort (e.g. by ascending padj).\n"
            "- In the chart, red bars are pathways with positive NES (enriched "
            "among genes higher in the first group, A), blue bars have negative NES "
            "(higher in the second group, B). The legend names the two groups.\n\n"
            "Manual annotations and high-resolution export: identical to those "
            "described for the PCA tab — use the 'Manual annotations' bar to "
            "highlight a pathway of particular interest with an arrow or box "
            "before exporting the figure with 'Export image'."
        ),
    },
    "ora": {
        "title": "Help — ORA / Over-representation",
        "meaning": (
            "ORA (Over-Representation Analysis) asks a simpler question than GSEA: "
            "'among the genes I declared differentially expressed, are there more "
            "genes of a given pathway than I would expect by chance?'.\n\n"
            "How it works, briefly: the significant genes (padj and log2FC below/above "
            "the cutoffs set in the Setup tab) are taken as a list; for each gene set "
            "a hypergeometric test compares how many of them fall in that pathway "
            "with how many would be expected given the size of the pathway. The "
            "background (universe) is the set of genes actually tested in the DEA, "
            "not the whole genome.\n\n"
            "- k/K: genes of the list that belong to the pathway (k) over the genes "
            "of the pathway present in the universe (K).\n"
            "- FE (fold enrichment): (k / list size) divided by (K / universe size). "
            "FE = 3 means the pathway is 3 times more represented than expected.\n"
            "- padj: hypergeometric p-value corrected for the number of pathways "
            "tested (Benjamini-Hochberg).\n"
            "- Direction: ORA itself has no direction (the list is unordered). It is "
            "derived afterwards from the genes supporting each pathway: UP / DOWN if "
            "at least 80% of them have log2FC > 0 (higher in the first group of the "
            "contrast) / < 0 (higher in the reference group), MIXED otherwise. N_UP and "
            "N_DOWN give the exact counts.\n\n"
            "ORA and GSEA are complementary, not alternatives: ORA depends on the "
            "cutoffs used to build the gene list and ignores the magnitude of the "
            "changes, while GSEA uses the whole ranking of genes."
        ),
        "usage": (
            "- 'Top N pathways': how many pathways to show (significant ones first; "
            "if none passes the padj cutoff, the top N by p-value are shown as exploratory).\n"
            "- 'Chart type': 'Bar' shows significance as bar length (-log10 padj), "
            "with k/K, FE and padj written next to each bar; 'Dot' shows the Gene "
            "Ratio on the X axis, dot size = number of genes, color = padj.\n"
            "- 'Custom title' + 'Apply': replaces the automatic title.\n"
            "- 'Export ORA table CSV...': saves the complete ORA table "
            "(all pathways tested, including the gene lists).\n"
            "- Which genes enter the ORA (all DEGs / only up / only down) is chosen "
            "in the Setup tab and requires re-running the analysis; the padj cutoff "
            "of this chart follows the Setup tab and updates without rerunning R.\n"
            "- If the tab says ORA is not available, the reason is shown (typically "
            "fewer than 5 genes passing the cutoffs, or ORA disabled in Setup).\n\n"
            "Manual annotations and high-resolution export: identical to those "
            "described for the PCA tab."
        ),
    },
    "genes": {
        "title": "Help — Gene counts",
        "meaning": (
            "This tab shows how much a single gene is expressed in EACH sample and relates it to the "
            "metadata of the samples (age, sex, tumor stage, batch...). Every point is a sample.\n\n"
            "The X axis is the normalized expression of the gene: log2(counts normalized for sequencing "
            "depth + 1) for RNA-seq, or the already normalized log2 values for microarray (the exact "
            "scale is written on the axis). These values are for exploration only: the differential "
            "expression results come from the statistical model fitted on the raw counts.\n\n"
            "- Numeric metadata (e.g. age): dot plot with Spearman's rank correlation (rho and p-value).\n"
            "- Text metadata (e.g. sex, stage): one box per group with the samples as points; "
            "Mann-Whitney U test for 2 groups, Kruskal-Wallis for 3 or more."
        ),
        "usage": (
            "- 'Gene': type a gene symbol (case does not matter) and press 'Plot' or Enter. If the gene is "
            "missing, similar names are suggested; genes removed by the low-counts filter are not available.\n"
            "- 'Metadata (Y axis)' and 'Type': the metadata column to compare; 'Auto' recognizes numeric vs "
            "text columns, or force the type.\n"
            "- 'Color points by': paints the points with ANOTHER metadata column (e.g. plot expression vs age "
            "and color by sex or by condition). Numeric columns get a color scale with a color bar, text "
            "columns one color per group; missing values ('not available', empty...) are grey.\n"
            "- 'Scale' and 'Color-blind-friendly palette': choose the numeric color scale / the Okabe-Ito "
            "palette for groups.\n"
            "- 'Show sample labels', 'Linear trend line', 'Custom title': cosmetic options.\n"
            "- 'Export plot data CSV...': saves the values behind the chart.\n"
            "- p-values need the Python package 'scipy' (pip install scipy); without it the charts are drawn "
            "but the test results are not shown.\n\n"
            "Manual annotations and high-resolution export: identical to those described for the PCA tab."
        ),
    },
    "log": {
        "title": "Help — Log",
        "meaning": (
            "This tab shows the text log of everything the R pipeline "
            "(DESeq2/limma + GSEA) printed during execution: informational "
            "messages, warnings, and any errors. It is the same kind of output you "
            "would see running the R script from the command line, useful for "
            "understanding exactly what was done (e.g. how many genes were "
            "filtered out for low counts, which experimental design was used, how "
            "many gene sets were tested in the GSEA) or for diagnosing an error."
        ),
        "usage": (
            "- The log fills in automatically during 'Group extraction' and 'Run analysis'.\n"
            "- 'Clear log': empties the text area (does not delete anything on disk).\n"
            "- 'Save log to file...': exports the current content to a .txt file, "
            "useful for attaching to a bug report or for your own internal project documentation."
        ),
    },
}