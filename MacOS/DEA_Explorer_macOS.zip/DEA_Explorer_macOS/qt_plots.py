"""Pannello grafico interattivo (Matplotlib dentro Qt) per DEA Explorer."""
from __future__ import annotations

import warnings

import matplotlib
matplotlib.use("QtAgg")
warnings.filterwarnings("ignore", message="constrained_layout not applied")
warnings.filterwarnings("ignore", message="Tight layout not applied")
import matplotlib.patches as mpatches
import numpy as np
from matplotlib import transforms
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.figure import Figure

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFormLayout,
                               QFrame, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QSizePolicy, QSpinBox, QFileDialog, QVBoxLayout, QWidget)

from help_content import EXPORT_PRESETS, LEGEND_POSITIONS
from qt_theme import PALETTE, ColorSwatch, Disclosure

try:
    import mplcursors
    HAS_MPLCURSORS = True
except ImportError:  # hover opzionale
    HAS_MPLCURSORS = False


def style_matplotlib() -> None:
    """Look coerente con l'interfaccia: pulito, leggibile, da pubblicazione."""
    matplotlib.rcParams.update({
        "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlepad": 12,
        "axes.labelsize": 10, "axes.labelcolor": "#1b2b3a", "axes.edgecolor": "#5a6672",
        "axes.linewidth": 0.9, "xtick.color": "#3a4856", "ytick.color": "#3a4856",
        "grid.color": "#cfd8e3", "grid.linewidth": 0.7, "legend.fontsize": 9,
        "figure.facecolor": "white", "axes.facecolor": "white",
        "font.family": "sans-serif",
        "font.sans-serif": ["Inter", "Helvetica Neue", "Helvetica", "Arial", "Segoe UI", "Noto Sans",
                            "Ubuntu", "DejaVu Sans"],
    })


style_matplotlib()


def confidence_ellipse(x, y, ax, n_std=1.5, **kwargs):
    if len(x) < 3:
        return None
    cov = np.cov(x, y)
    if cov[0, 0] <= 0 or cov[1, 1] <= 0:
        return None
    pearson = cov[0, 1] / np.sqrt(cov[0, 0] * cov[1, 1])
    pearson = max(min(pearson, 0.999), -0.999)
    radius_x = np.sqrt(1 + pearson)
    radius_y = np.sqrt(1 - pearson)
    ellipse = mpatches.Ellipse((0, 0), width=radius_x * 2, height=radius_y * 2, **kwargs)
    scale_x = np.sqrt(cov[0, 0]) * n_std
    scale_y = np.sqrt(cov[1, 1]) * n_std
    mean_x, mean_y = np.mean(x), np.mean(y)
    transf = (transforms.Affine2D().rotate_deg(45).scale(scale_x, scale_y).translate(mean_x, mean_y))
    ellipse.set_transform(transf + ax.transData)
    return ax.add_patch(ellipse)


# --------------------------------------------------------------------------- export
class ExportDialog(QDialog):
    def __init__(self, panel: "PlotPanel"):
        super().__init__(panel)
        self.panel = panel
        self.setWindowTitle("Export image")
        self.setModal(True)
        cur_w, cur_h = panel.figure.get_size_inches()
        self._aspect = float(cur_w) / float(cur_h) if cur_h else 1.0

        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.setSpacing(12)
        title = QLabel("Export figure")
        title.setObjectName("h1")
        lay.addWidget(title)

        form = QFormLayout()
        form.setHorizontalSpacing(18)
        form.setVerticalSpacing(10)
        self.preset = QComboBox()
        self.preset.addItems(list(EXPORT_PRESETS.keys()))
        self.preset.setToolTip("Standard width/height for single, 1.5 or double column journals.")
        form.addRow("Size preset (journals)", self.preset)
        self.fmt = QComboBox()
        self.fmt.addItems(["PNG", "PDF", "SVG", "TIFF", "EPS"])
        form.addRow("File format", self.fmt)
        self.dpi = QComboBox()
        self.dpi.setEditable(True)
        self.dpi.addItems(["150", "300", "600", "1200"])
        self.dpi.setCurrentText("300")
        form.addRow("Resolution (DPI)", self.dpi)
        self.width = QDoubleSpinBox()
        self.width.setRange(2.0, 20.0)
        self.width.setSingleStep(0.5)
        self.width.setDecimals(2)
        self.width.setValue(round(float(cur_w), 2))
        form.addRow("Width (inches)", self.width)
        self.height = QDoubleSpinBox()
        self.height.setRange(2.0, 20.0)
        self.height.setSingleStep(0.5)
        self.height.setDecimals(2)
        self.height.setValue(round(float(cur_h), 2))
        form.addRow("Height (inches)", self.height)
        lay.addLayout(form)

        self.lock = QCheckBox("Lock aspect ratio (width / height)")
        self.transparent = QCheckBox("Transparent background")
        lay.addWidget(self.lock)
        lay.addWidget(self.transparent)
        tip = QLabel("PDF / SVG / EPS are vector formats: perfect quality at any size.\n"
                     "Most journals require at least 300 DPI (often 600 for colour TIFF/EPS).")
        tip.setObjectName("muted")
        lay.addWidget(tip)

        row = QHBoxLayout()
        row.addStretch()
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Save…")
        save.setObjectName("primary")
        save.clicked.connect(self._do_export)
        row.addWidget(cancel)
        row.addWidget(save)
        lay.addLayout(row)

        self.preset.currentTextChanged.connect(self._on_preset)
        self.width.valueChanged.connect(self._on_width)

    def _on_preset(self, name: str):
        p = EXPORT_PRESETS.get(name)
        if p:
            self.width.setValue(round(p[0], 2))
            self.height.setValue(round(p[1], 2))

    def _on_width(self, v: float):
        if self.lock.isChecked() and self._aspect:
            self.height.blockSignals(True)
            self.height.setValue(round(v / self._aspect, 2))
            self.height.blockSignals(False)

    def _do_export(self):
        ext = {"PNG": ".png", "PDF": ".pdf", "SVG": ".svg", "TIFF": ".tiff", "EPS": ".eps"}[self.fmt.currentText()]
        path, _ = QFileDialog.getSaveFileName(self, "Save figure", "figure" + ext,
                                              f"{self.fmt.currentText()} (*{ext})")
        if not path:
            return
        if not path.lower().endswith(ext):
            path += ext
        fig = self.panel.figure
        orig = fig.get_size_inches().copy()
        try:
            fig.set_size_inches(self.width.value(), self.height.value())
            fig.savefig(path, dpi=int(float(self.dpi.currentText())), transparent=self.transparent.isChecked(),
                        bbox_inches="tight", pad_inches=0.15)
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Export error", str(e))
            return
        finally:
            fig.set_size_inches(*orig)
            self.panel.canvas.draw_idle()
        self.accept()


# --------------------------------------------------------------------------- panel
class PlotPanel(QWidget):
    """Grafico + barra Matplotlib + stile da pubblicazione + annotazioni manuali."""

    def __init__(self, explanation: str, figsize=(6.4, 5.0), redraw_callback=None, min_height: int = 320):
        super().__init__()
        self.redraw_callback = redraw_callback or (lambda: None)
        self.on_exported = None
        self.annotation_color = "#2c3e50"

        self.figure = Figure(figsize=figsize, dpi=100, layout="constrained")
        self.figure.get_layout_engine().set(w_pad=0.08, h_pad=0.08)
        self.figure.patch.set_facecolor("white")
        self.ax = self.figure.add_subplot(111)
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.canvas.setMinimumHeight(min_height)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.toolbar = NavigationToolbar2QT(self.canvas, self)
        self.toolbar.setStyleSheet(
            "QToolBar { background: transparent; border: none; spacing: 2px; }"
            f"QToolButton {{ border: none; border-radius: 6px; padding: 5px; }}"
            f"QToolButton:hover {{ background: {PALETTE['accent_pale']}; }}"
            f"QToolButton:checked {{ background: {PALETTE['accent_pale']}; border: 1px solid {PALETTE['accent']}; }}"
            f"QLabel {{ color: {PALETTE['muted']}; font-size: 8.5pt; }}")

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)

        # barra superiore: strumenti mpl + export
        top = QHBoxLayout()
        top.addWidget(self.toolbar, 1)
        self.btn_export = QPushButton("Export image")
        self.btn_export.setObjectName("primary")
        self.btn_export.setStyleSheet("padding: 7px 18px; font-size: 9.5pt;")
        self.btn_export.setToolTip("Save this chart in high resolution with journal-format presets.")
        self.btn_export.clicked.connect(self._open_export_dialog)
        top.addWidget(self.btn_export)
        root.addLayout(top)

        # canvas dentro un frame "card"
        frame = QFrame()
        frame.setObjectName("card")
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(6, 6, 6, 6)
        fl.addWidget(self.canvas)
        root.addWidget(frame, 1)

        self._build_drawer(root)

        info = QLabel(explanation)
        info.setWordWrap(True)
        info.setObjectName("cardHint")
        info.setStyleSheet(f"background: {PALETTE['accent_pale_2']}; border-radius: 8px; padding: 10px 12px;")
        root.addWidget(Disclosure("About this chart", info, expanded=False))

        self.annotation_mode = "none"
        self.annotation_color = "#2c3e50"
        self.custom_artists: list = []
        self._drag_start = None
        self.canvas.mpl_connect("button_press_event", self._on_press)
        self.canvas.mpl_connect("button_release_event", self._on_release)

    # ------------------------------------------------ stile + annotazioni
    def _build_drawer(self, root: QVBoxLayout):
        box = QWidget()
        g = QVBoxLayout(box)
        g.setContentsMargins(0, 4, 0, 4)
        g.setSpacing(8)

        r1 = QHBoxLayout()
        r1.setSpacing(10)
        lbl = QLabel("Figure style")
        lbl.setObjectName("fieldLabel")
        r1.addWidget(lbl)
        self.cb_grid = QCheckBox("Grid")
        self.cb_grid.setChecked(True)
        self.cb_grid.setToolTip("Shows/hides the grid lines behind the chart.")
        self.cb_spines = QCheckBox("Minimalist axes")
        self.cb_spines.setChecked(True)
        self.cb_spines.setToolTip("Hides the top and right borders, as in most journals.")
        self.cb_legend = QCheckBox("Legend")
        self.cb_legend.setChecked(True)
        self.legend_pos = QComboBox()
        self.legend_pos.addItems(LEGEND_POSITIONS)
        self.legend_pos.setToolTip("'outside' places the legend outside the plot area.")
        self.font_style = QComboBox()
        self.font_style.addItems(["sans", "serif"])
        self.font_style.setToolTip("Many journals require a serif font; 'sans' suits slides and posters.")
        self.panel_label = QLineEdit()
        self.panel_label.setMaximumWidth(48)
        self.panel_label.setPlaceholderText("A")
        self.panel_label.setToolTip("Adds a bold panel letter (A, B, C…) in the top-left corner.")
        self.panel_size = QSpinBox()
        self.panel_size.setRange(8, 28)
        self.panel_size.setValue(14)
        for w in (self.cb_grid, self.cb_spines, self.cb_legend):
            r1.addWidget(w)
        r1.addWidget(self.legend_pos)
        r1.addWidget(QLabel("Font"))
        r1.addWidget(self.font_style)
        r1.addWidget(QLabel("Panel"))
        r1.addWidget(self.panel_label)
        r1.addWidget(self.panel_size)
        r1.addStretch()
        g.addLayout(r1)

        r2 = QHBoxLayout()
        r2.setSpacing(6)
        lbl2 = QLabel("Annotate")
        lbl2.setObjectName("fieldLabel")
        r2.addWidget(lbl2)
        self._mode_group = QButtonGroup(self)
        self._mode_group.setExclusive(True)
        for label, val in (("None", "none"), ("Arrow", "arrow"), ("Line", "line"), ("Box", "rect"), ("Text", "text")):
            b = QPushButton(label)
            b.setCheckable(True)
            b.setStyleSheet("padding: 4px 12px;")
            b.setProperty("mode", val)
            if val == "none":
                b.setChecked(True)
            self._mode_group.addButton(b)
            r2.addWidget(b)
        self._mode_group.buttonClicked.connect(lambda b: setattr(self, "annotation_mode", b.property("mode")))
        r2.addSpacing(10)
        r2.addWidget(QLabel("Color"))
        self.color_swatch = ColorSwatch("#2c3e50")
        self.color_swatch.colorChanged.connect(lambda c: setattr(self, "annotation_color", c))
        r2.addWidget(self.color_swatch)
        r2.addWidget(QLabel("Width"))
        self.annotation_lw = QDoubleSpinBox()
        self.annotation_lw.setRange(0.5, 6.0)
        self.annotation_lw.setSingleStep(0.5)
        self.annotation_lw.setValue(1.5)
        r2.addWidget(self.annotation_lw)
        undo = QPushButton("Undo last")
        undo.clicked.connect(self._undo_annotation)
        clear = QPushButton("Clear all")
        clear.clicked.connect(self._clear_annotations)
        r2.addWidget(undo)
        r2.addWidget(clear)
        r2.addStretch()
        g.addLayout(r2)

        # ricolora quando cambia uno stile
        for w in (self.cb_grid, self.cb_spines, self.cb_legend):
            w.toggled.connect(lambda _=None: self.redraw_callback())
        self.legend_pos.currentTextChanged.connect(lambda _=None: self.redraw_callback())
        self.font_style.currentTextChanged.connect(lambda _=None: self.redraw_callback())
        self.panel_label.editingFinished.connect(self.redraw_callback)
        self.panel_size.valueChanged.connect(lambda _=None: self.redraw_callback())

        root.addWidget(Disclosure("Figure style & annotations (publication tools)", box, expanded=False))

    def legend_enabled(self) -> bool:
        return self.cb_legend.isChecked()

    def apply_common_style(self):
        ax = self.ax
        ax.grid(self.cb_grid.isChecked(), alpha=0.25)
        show_side = not self.cb_spines.isChecked()
        for side in ("top", "right"):
            ax.spines[side].set_visible(show_side)
        family = "serif" if self.font_style.currentText() == "serif" else "sans-serif"
        objs = [ax.title, ax.xaxis.label, ax.yaxis.label]
        objs += list(ax.get_xticklabels()) + list(ax.get_yticklabels())
        legend = ax.get_legend()
        if legend:
            objs += list(legend.get_texts())
            if legend.get_title():
                objs.append(legend.get_title())
        for o in objs:
            try:
                o.set_family(family)
            except Exception:  # noqa: BLE001
                pass
        label = self.panel_label.text().strip()
        if label:
            ax.text(-0.12, 1.06, label, transform=ax.transAxes, fontsize=self.panel_size.value(),
                    fontweight="bold", va="bottom", ha="left")

    def place_legend(self, **kwargs):
        if not self.legend_enabled():
            leg = self.ax.get_legend()
            if leg:
                leg.remove()
            return
        pos = self.legend_pos.currentText()
        if pos == "outside":
            self.ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1), borderaxespad=0, frameon=False, **kwargs)
        else:
            self.ax.legend(loc=pos, frameon=False, **kwargs)

    # ------------------------------------------------ disegno
    def clear(self):
        self.ax.clear()
        self.custom_artists = []
        self.canvas.draw_idle()

    def redraw(self):
        self.canvas.draw_idle()

    def enable_hover(self, artist, formatter):
        if not HAS_MPLCURSORS:
            return
        cursor = mplcursors.cursor(artist, hover=True)

        @cursor.connect("add")
        def _(sel):
            sel.annotation.set_text(formatter(sel.index))
            sel.annotation.get_bbox_patch().set(fc="lightyellow", alpha=0.95)

    # ------------------------------------------------ annotazioni
    def _on_press(self, event):
        if event.inaxes != self.ax or self.annotation_mode == "none":
            return
        if getattr(self.toolbar, "mode", ""):
            return
        if self.annotation_mode == "text":
            self._add_text_annotation(event.xdata, event.ydata)
            return
        self._drag_start = (event.xdata, event.ydata)

    def _on_release(self, event):
        if self._drag_start is None:
            return
        x0, y0 = self._drag_start
        self._drag_start = None
        if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            return
        x1, y1 = event.xdata, event.ydata
        if x0 == x1 and y0 == y1:
            return
        mode, color, lw = self.annotation_mode, self.annotation_color, self.annotation_lw.value()
        artist = None
        if mode == "arrow":
            artist = self.ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                                      arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, mutation_scale=14))
        elif mode == "line":
            (artist,) = self.ax.plot([x0, x1], [y0, y1], color=color, lw=lw, solid_capstyle="round")
        elif mode == "rect":
            artist = mpatches.Rectangle((min(x0, x1), min(y0, y1)), abs(x1 - x0), abs(y1 - y0), fill=False,
                                        edgecolor=color, linewidth=lw)
            self.ax.add_patch(artist)
        if artist is not None:
            self.custom_artists.append(artist)
            self.redraw()

    def _add_text_annotation(self, x, y):
        text, ok = QInputDialog.getText(self, "Add text", "Annotation text:")
        if ok and text:
            artist = self.ax.text(x, y, text, fontsize=10, color=self.annotation_color, ha="center", va="center",
                                  bbox=dict(boxstyle="round,pad=0.25", fc="white", ec=self.annotation_color, alpha=0.9))
            self.custom_artists.append(artist)
            self.redraw()

    def _undo_annotation(self):
        if not self.custom_artists:
            return
        artist = self.custom_artists.pop()
        try:
            artist.remove()
        except Exception:  # noqa: BLE001
            pass
        self.redraw()

    def _clear_annotations(self):
        for a in self.custom_artists:
            try:
                a.remove()
            except Exception:  # noqa: BLE001
                pass
        self.custom_artists = []
        self.redraw()

    def _open_export_dialog(self):
        dlg = ExportDialog(self)
        if dlg.exec() == QDialog.Accepted and callable(self.on_exported):
            self.on_exported()
