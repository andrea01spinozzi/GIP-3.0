# Installs the R packages needed by DEA Explorer.  Run once:  Rscript install_r_packages.R
# Optional species annotation: Rscript install_r_packages.R mouse rat zebrafish
args <- tolower(commandArgs(trailingOnly = TRUE))
options(repos = c(CRAN = "https://cloud.r-project.org"), Ncpus = max(1L, parallel::detectCores() - 1L))

if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")

cran <- c("tidyverse", "readxl", "jsonlite", "msigdbr", "ggpubr", "data.table")
bioc <- c("DESeq2", "fgsea", "clusterProfiler", "limma", "BiocParallel", "edgeR",
          "glmGamPoi", "AnnotationDbi", "org.Hs.eg.db")
if ("mouse"     %in% args) bioc <- c(bioc, "org.Mm.eg.db")
if ("rat"       %in% args) bioc <- c(bioc, "org.Rn.eg.db")
if ("zebrafish" %in% args) bioc <- c(bioc, "org.Dr.eg.db")

need <- function(p) !requireNamespace(p, quietly = TRUE)
if (any(sapply(cran, need))) install.packages(cran[sapply(cran, need)])
if (any(sapply(bioc, need))) BiocManager::install(bioc[sapply(bioc, need)], ask = FALSE, update = FALSE)

missing <- c(cran, bioc)[sapply(c(cran, bioc), need)]
if (length(missing)) {
  cat("\nSTILL MISSING:", paste(missing, collapse = ", "), "\n"); quit(status = 1)
} else cat("\nAll R packages are installed.\n")
