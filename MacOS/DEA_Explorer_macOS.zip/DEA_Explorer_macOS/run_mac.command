#!/bin/bash
# Double-click to start DEA Explorer on macOS.
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "First run: running setup..."
  ./setup_mac.sh || { echo; read -r -p "Setup failed. Press Enter to close."; exit 1; }
fi
source .venv/bin/activate
export PATH="/Library/Frameworks/R.framework/Resources/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
export LANG="${LANG:-en_US.UTF-8}"
python main.py
status=$?
if [ $status -ne 0 ]; then echo; read -r -p "The app exited with an error. Press Enter to close."; fi
