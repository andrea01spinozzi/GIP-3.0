"""Tema e widget di base per DEA Explorer (PySide6).

Palette: blu inchiostro + grigi freddi, accenti sobri; pensata per un software
scientifico (alto contrasto, niente decorazioni inutili).
"""
from __future__ import annotations

import os
import re
import sys
import tempfile

from PySide6.QtCore import (Qt, QPropertyAnimation, QEasingCurve, QTimer, Signal, QSize)
from PySide6.QtGui import QColor, QFont, QFontDatabase, QImage, QPainter, QPen, QPainterPath
from PySide6.QtWidgets import (QApplication, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel,
                               QPushButton, QSizePolicy, QToolButton, QVBoxLayout, QWidget,
                               QFileDialog, QComboBox)

PALETTE = {
    "bg": "#f3f6fa",
    "card": "#ffffff",
    "ink": "#0b2f52",          # blu istituzionale (header, testi forti)
    "accent": "#1f6fb2",
    "accent_hover": "#18598f",
    "accent_pale": "#e6f0f9",
    "accent_pale_2": "#f0f5fa",
    "text": "#1b2b3a",
    "muted": "#6b7a89",
    "border": "#dbe4ee",
    "border_strong": "#b9cbdd",
    "up": "#c0392b",
    "down": "#2471a3",
    "ns": "#999b9d",
    "ok": "#1e8449",
    "warn": "#b9770e",
    "err": "#c0392b",
    "sidebar": "#0b2f52",
    "sidebar_hover": "#13426f",
    "sidebar_active": "#1f6fb2",
}

# macOS: native fonts first (SF Pro is exposed by Qt as ".AppleSystemUIFont" / "Helvetica Neue").
SANS = ('"Inter", "Helvetica Neue", "SF Pro Text", "Segoe UI", "Noto Sans", "Ubuntu", "Cantarell", '
        '"DejaVu Sans", sans-serif')
MONO = ('"JetBrains Mono", "Fira Code", "Menlo", "SF Mono", "Monaco", "Consolas", "DejaVu Sans Mono", '
        'monospace')

IS_MAC = sys.platform == "darwin"
# Qt on macOS uses 72 logical DPI (1 pt = 1 px) while Windows uses 96 DPI (1 pt = 1.33 px).
# Every font size written in the style sheets was tuned on Windows, so on macOS they are scaled
# by 96/72 to keep exactly the same on-screen size.
PT_SCALE = 96.0 / 72.0 if IS_MAC else 1.0
MOD_NAME = "\u2318" if IS_MAC else "Ctrl"      # "Cmd" symbol used in user-visible shortcut hints


def scale_pt(css: str) -> str:
    """Rescales every '<n>pt' in a Qt style sheet (identity on Windows/Linux)."""
    if PT_SCALE == 1.0 or "pt" not in css:
        return css
    return re.sub(r"(\d+(?:\.\d+)?)pt\b", lambda m: f"{float(m.group(1)) * PT_SCALE:.1f}pt", css)


def shortcut_hint(text: str) -> str:
    """'Ctrl+R' -> '\u2318R' on macOS (display only; QKeySequence('Ctrl+R') already maps to Cmd on macOS)."""
    if not IS_MAC:
        return text
    return text.replace("Ctrl+", "\u2318").replace("Ctrl/", "\u2318/")


def _install_stylesheet_scaling() -> None:
    """Makes every inline widget.setStyleSheet('... 9.5pt ...') of the app go through scale_pt()."""
    if PT_SCALE == 1.0 or getattr(QWidget, "_dea_pt_patched", False):
        return
    _orig = QWidget.setStyleSheet

    def _patched(self, sheet):
        return _orig(self, scale_pt(sheet))
    QWidget.setStyleSheet = _patched
    QWidget._dea_pt_patched = True


def _make_check_icon() -> str:
    """Spunta bianca per le checkbox (Qt non ne disegna una con gli stili personalizzati)."""
    d = os.path.join(tempfile.gettempdir(), "dea_explorer_assets")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, "check.png")
    img = QImage(34, 34, QImage.Format_ARGB32)
    img.fill(Qt.transparent)
    pt = QPainter(img)
    pt.setRenderHint(QPainter.Antialiasing)
    pen = QPen(QColor("white"), 4.2)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    pt.setPen(pen)
    path_ = QPainterPath()
    path_.moveTo(9, 18)
    path_.lineTo(15, 24)
    path_.lineTo(25, 11)
    pt.drawPath(path_)
    pt.end()
    img.save(path)
    return path.replace("\\", "/")


def build_stylesheet() -> str:
    p = PALETTE
    check = _make_check_icon()
    return f"""
* {{ font-family: {SANS}; font-size: 10pt; color: {p['text']}; }}
QMainWindow, QWidget#root {{ background: {p['bg']}; }}
QWidget#page {{ background: {p['bg']}; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QToolTip {{ background: {p['ink']}; color: white; border: none; padding: 6px 8px; }}

/* ---------- header ---------- */
QFrame#header {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {p['ink']}, stop:1 #164a7a); }}
QLabel#appTitle {{ color: white; font-size: 17pt; font-weight: 700; letter-spacing: 0.3px; }}
QLabel#appSubtitle {{ color: #b9d3ec; font-size: 9.5pt; }}
QLabel#badge {{ background: rgba(255,255,255,0.16); color: white; border-radius: 9px;
               padding: 2px 8px; font-size: 7.5pt; font-weight: 700; }}
QPushButton#headerBtn {{ background: rgba(255,255,255,0.12); color: white; border: 1px solid rgba(255,255,255,0.25);
                        border-radius: 8px; padding: 6px 14px; font-weight: 600; }}
QPushButton#headerBtn:hover {{ background: rgba(255,255,255,0.22); }}

/* ---------- sidebar ---------- */
QFrame#sidebar {{ background: {p['sidebar']}; }}
QLabel#sideSection {{ color: #7fa6cc; font-size: 7.5pt; font-weight: 700; letter-spacing: 1.2px;
                     padding: 14px 18px 4px 18px; }}
QPushButton#nav {{ background: transparent; border: none; border-radius: 9px; text-align: left;
                  color: #d6e6f5; padding: 9px 12px; margin: 1px 10px; font-weight: 500; }}
QPushButton#nav:hover {{ background: {p['sidebar_hover']}; }}
QPushButton#nav:checked {{ background: {p['sidebar_active']}; color: white; font-weight: 700; }}
QPushButton#nav:disabled {{ color: #5e7d9c; }}
QLabel#sideFoot {{ color: #6d92b8; font-size: 8pt; padding: 10px 18px; }}

/* ---------- card ---------- */
QFrame#card {{ background: {p['card']}; border: 1px solid {p['border']}; border-radius: 12px; }}
QLabel#cardTitle {{ font-size: 10.5pt; font-weight: 700; color: {p['ink']}; }}
QLabel#cardHint {{ color: {p['muted']}; font-size: 9pt; }}
QLabel#h1 {{ font-size: 15pt; font-weight: 700; color: {p['ink']}; }}
QLabel#muted {{ color: {p['muted']}; }}
QLabel#direction {{ color: {p['ink']}; font-weight: 600; background: {p['accent_pale']};
                   border-radius: 8px; padding: 7px 12px; }}
QLabel#fieldLabel {{ color: {p['muted']}; font-size: 8.5pt; font-weight: 600; }}

/* ---------- inputs ---------- */
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit, QTextEdit {{
    background: white; border: 1px solid {p['border_strong']}; border-radius: 7px; padding: 5px 8px;
    selection-background-color: {p['accent']}; selection-color: white; }}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{ border: 1.5px solid {p['accent']}; }}
QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled, QComboBox:disabled {{
    background: {p['accent_pale_2']}; color: {p['muted']}; }}
QLineEdit[invalid="true"] {{ border: 1.5px solid {p['err']}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: white; border: 1px solid {p['border_strong']};
    selection-background-color: {p['accent_pale']}; selection-color: {p['ink']}; outline: none; padding: 4px; }}
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{ width: 16px; border: none; }}

QCheckBox, QRadioButton {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 17px; height: 17px; border-radius: 5px; border: 1.5px solid {p['border_strong']}; background: white; }}
QCheckBox::indicator:checked {{ background: {p['accent']}; border-color: {p['accent']}; image: url({check}); }}
QCheckBox::indicator:disabled {{ background: {p['accent_pale_2']}; }}
QRadioButton::indicator {{ width: 17px; height: 17px; border-radius: 9px; border: 1.5px solid {p['border_strong']}; background: white; }}
QRadioButton::indicator:checked {{ background: qradialgradient(cx:.5,cy:.5,radius:.5,fx:.5,fy:.5,
    stop:0 {p['accent']}, stop:.45 {p['accent']}, stop:.5 white, stop:1 white); border-color: {p['accent']}; }}

QSlider::groove:horizontal {{ height: 6px; background: {p['border']}; border-radius: 3px; }}
QSlider::sub-page:horizontal {{ background: {p['accent']}; border-radius: 3px; }}
QSlider::handle:horizontal {{ background: white; border: 2px solid {p['accent']}; width: 14px; height: 14px;
    margin: -6px 0; border-radius: 8px; }}

/* ---------- buttons ---------- */
QPushButton {{ background: white; border: 1px solid {p['border_strong']}; border-radius: 8px; padding: 7px 14px; font-weight: 600; }}
QPushButton:hover {{ background: {p['accent_pale']}; border-color: {p['accent']}; }}
QPushButton:pressed {{ background: #d3e5f6; }}
QPushButton:disabled {{ color: #a3b0bd; background: {p['accent_pale_2']}; border-color: {p['border']}; }}
QPushButton#primary {{ background: {p['accent']}; color: white; border: none; padding: 10px 26px; font-size: 10.5pt; }}
QPushButton#primary:hover {{ background: {p['accent_hover']}; }}
QPushButton#primary:disabled {{ background: #b7c9da; color: white; }}
QPushButton#ghost {{ background: transparent; border: none; color: {p['accent']}; padding: 4px 8px; }}
QPushButton#ghost:hover {{ background: {p['accent_pale']}; }}
QPushButton#danger {{ color: {p['err']}; }}
QPushButton#danger:hover {{ background: #fdecea; border-color: {p['err']}; }}
QPushButton#swatch {{ border: 1px solid {p['border_strong']}; border-radius: 6px; padding: 0; min-width: 26px; max-width: 26px; min-height: 22px; max-height: 22px; }}
QToolButton#disclosure {{ border: none; background: transparent; font-weight: 700; color: {p['ink']}; padding: 4px 2px; }}
QToolButton#disclosure:hover {{ color: {p['accent']}; }}

/* ---------- chips (stato) ---------- */
QLabel#chip {{ border-radius: 10px; padding: 4px 12px; font-weight: 600; background: {p['accent_pale_2']}; color: {p['muted']}; border: 1px solid {p['border']}; }}
QLabel#chip[state="ok"] {{ background: #e5f4ea; color: {p['ok']}; border-color: #bfe3cb; }}
QLabel#chip[state="err"] {{ background: #fdecea; color: {p['err']}; border-color: #f4c7c1; }}

/* ---------- drop zone ---------- */
QFrame#drop {{ background: {p['accent_pale_2']}; border: 2px dashed {p['border_strong']}; border-radius: 12px; }}
QFrame#drop[hover="true"] {{ background: {p['accent_pale']}; border-color: {p['accent']}; }}
QFrame#drop[filled="true"] {{ background: #eef8f1; border: 2px solid #9fd3b2; }}
QLabel#dropTitle {{ font-weight: 700; color: {p['ink']}; font-size: 11pt; }}
QLabel#dropPath {{ color: {p['muted']}; font-size: 9pt; }}

/* ---------- tabelle ---------- */
QTableView {{ background: white; alternate-background-color: #f7fafd; border: 1px solid {p['border']}; border-radius: 10px;
    gridline-color: transparent; selection-background-color: {p['accent_pale']}; selection-color: {p['ink']}; outline: none; }}
QTableView::item {{ padding: 4px 8px; border: none; }}
QHeaderView::section {{ background: {p['accent_pale_2']}; color: {p['ink']}; font-weight: 700; border: none;
    border-bottom: 1px solid {p['border_strong']}; padding: 8px 10px; }}
QTableCornerButton::section {{ background: {p['accent_pale_2']}; border: none; }}

/* ---------- menu contestuali ---------- */
QMenu {{ background: white; border: 1px solid {p['border_strong']}; padding: 6px; }}
QMenu::item {{ background: transparent; color: {p['text']}; padding: 7px 28px 7px 14px; border-radius: 6px; margin: 1px 2px; }}
QMenu::item:selected {{ background: {p['accent_pale']}; color: {p['ink']}; }}
QMenu::item:disabled {{ color: #a3b0bd; background: transparent; }}
QMenu::separator {{ height: 1px; background: {p['border']}; margin: 5px 8px; }}

/* ---------- scrollbar ---------- */
QScrollBar:vertical {{ background: transparent; width: 11px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #c3d1df; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #a6bad0; }}
QScrollBar:horizontal {{ background: transparent; height: 11px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: #c3d1df; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

QProgressBar {{ border: none; background: {p['border']}; border-radius: 4px; max-height: 8px; min-height: 8px; text-align: center; }}
QProgressBar::chunk {{ background: {p['accent']}; border-radius: 4px; }}

QStatusBar {{ background: white; border-top: 1px solid {p['border']}; }}
QStatusBar QLabel {{ color: {p['muted']}; padding: 2px 8px; }}
QSplitter::handle {{ background: transparent; }}
QSplitter::handle:horizontal {{ width: 8px; }}
QSplitter::handle:vertical {{ height: 8px; }}
QDialog {{ background: {p['bg']}; }}
QTabWidget::pane {{ border: 1px solid {p['border']}; border-radius: 10px; background: white; top: -1px; }}
QTabBar::tab {{ background: transparent; padding: 8px 18px; font-weight: 600; color: {p['muted']}; border-bottom: 2px solid transparent; }}
QTabBar::tab:selected {{ color: {p['ink']}; border-bottom: 2px solid {p['accent']}; }}
"""


def apply_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    _install_stylesheet_scaling()
    app.setStyleSheet(scale_pt(build_stylesheet()))
    f = app.font()
    f.setPointSizeF(10 * PT_SCALE)
    app.setFont(f)


def repolish(w: QWidget) -> None:
    w.style().unpolish(w)
    w.style().polish(w)
    w.update()


# ------------------------------------------------------------------ widget base
class Card(QFrame):
    """Contenitore bianco con bordo sottile e titolo opzionale."""

    def __init__(self, title: str = "", hint: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(18, 14, 18, 16)
        self._lay.setSpacing(10)
        if title:
            head = QVBoxLayout()
            head.setSpacing(1)
            t = QLabel(title)
            t.setObjectName("cardTitle")
            head.addWidget(t)
            if hint:
                h = QLabel(hint)
                h.setObjectName("cardHint")
                h.setWordWrap(True)
                head.addWidget(h)
            self._lay.addLayout(head)

    def body(self) -> QVBoxLayout:
        return self._lay


def field(label: str, widget: QWidget, tip: str = "") -> QWidget:
    """Etichetta piccola sopra al controllo."""
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(3)
    lb = QLabel(label.upper())
    lb.setObjectName("fieldLabel")
    lay.addWidget(lb)
    lay.addWidget(widget)
    if tip:
        box.setToolTip(tip)
        widget.setToolTip(tip)
    return box


class Chip(QLabel):
    """Pillola di stato: neutro / ok / errore."""

    def __init__(self, text: str = ""):
        super().__init__(text)
        self.setObjectName("chip")
        self.setProperty("state", "idle")

    def set_state(self, state: str, text: str | None = None):
        if text is not None:
            self.setText(text)
        self.setProperty("state", state)
        repolish(self)


class RefreshCombo(QComboBox):
    """Combo che ricarica la lista un attimo prima di aprirsi (come 'postcommand' in Tk)."""

    def __init__(self, refresh_cb=None, parent=None):
        super().__init__(parent)
        self._refresh_cb = refresh_cb

    def showPopup(self):
        if self._refresh_cb:
            self._refresh_cb()
        super().showPopup()


class ColorSwatch(QPushButton):
    colorChanged = Signal(str)

    def __init__(self, color: str):
        super().__init__()
        self.setObjectName("swatch")
        self.setCursor(Qt.PointingHandCursor)
        self._color = color
        self._apply()
        self.clicked.connect(self._pick)

    def color(self) -> str:
        return self._color

    def set_color(self, color: str):
        self._color = color
        self._apply()

    def _apply(self):
        self.setStyleSheet(f"QPushButton#swatch {{ background: {self._color}; }}")

    def _pick(self):
        from PySide6.QtWidgets import QColorDialog
        c = QColorDialog.getColor(QColor(self._color), self, "Choose color")
        if c.isValid():
            self.set_color(c.name())
            self.colorChanged.emit(c.name())


class Disclosure(QWidget):
    """Sezione richiudibile (freccia + titolo)."""

    def __init__(self, title: str, content: QWidget, expanded: bool = False):
        super().__init__()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)
        self.btn = QToolButton()
        self.btn.setObjectName("disclosure")
        self.btn.setText(title.replace("&", "&&"))
        self.btn.setCheckable(True)
        self.btn.setChecked(expanded)
        self.btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.btn.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self.btn.clicked.connect(self._toggle)
        self.content = content
        self.content.setVisible(expanded)
        lay.addWidget(self.btn, alignment=Qt.AlignLeft)
        lay.addWidget(self.content)

    def _toggle(self, on: bool):
        self.btn.setArrowType(Qt.DownArrow if on else Qt.RightArrow)
        self.content.setVisible(on)


class Toast(QLabel):
    """Notifica non bloccante in basso a destra, con dissolvenza."""

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setStyleSheet(
            f"background: {PALETTE['ink']}; color: white; border-radius: 10px; padding: 10px 16px; font-weight: 600;")
        self.hide()
        self._fx = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._fx)
        self._anim = QPropertyAnimation(self._fx, b"opacity", self)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._fade_out)

    def show_message(self, text: str, ms: int = 3200):
        self.setText(text)
        self.adjustSize()
        p = self.parentWidget()
        self.move(p.width() - self.width() - 24, p.height() - self.height() - 52)
        self.raise_()
        self.show()
        self._anim.stop()
        self._anim.setDuration(180)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.start()
        self._timer.start(ms)

    def _fade_out(self):
        self._anim.stop()
        self._anim.setDuration(400)
        self._anim.setStartValue(1.0)
        self._anim.setEndValue(0.0)
        self._anim.finished.connect(self._after_fade)
        self._anim.start()

    def _after_fade(self):
        try:
            self._anim.finished.disconnect(self._after_fade)
        except (TypeError, RuntimeError):
            pass
        self.hide()


def fade_in(widget: QWidget, ms: int = 220):
    """Dissolvenza leggera quando si cambia pagina."""
    fx = QGraphicsOpacityEffect(widget)
    widget.setGraphicsEffect(fx)
    anim = QPropertyAnimation(fx, b"opacity", widget)
    anim.setDuration(ms)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    anim.finished.connect(lambda: widget.setGraphicsEffect(None))
    anim.start(QPropertyAnimation.DeleteWhenStopped)
    widget._fade_anim = anim


class NavButton(QPushButton):
    def __init__(self, number: str, text: str):
        super().__init__(f"  {number}   {text}".replace("&", "&&"))
        self.setObjectName("nav")
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(38)


class DropZone(QFrame):
    """Area di selezione file con drag & drop nativo (nessuna dipendenza extra)."""
    pathChanged = Signal(str)

    EXTS = (".csv", ".tsv", ".txt", ".xlsx", ".xls", ".json")

    def __init__(self, title: str, subtitle: str, glyph: str, pick_cb):
        super().__init__()
        self.setObjectName("drop")
        self.setAcceptDrops(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(112)
        self._pick_cb = pick_cb
        self._path = ""
        lay = QHBoxLayout(self)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(14)
        self.glyph = QLabel(glyph)
        self.glyph.setStyleSheet(f"font-size: 22pt; color: {PALETTE['accent']}; font-weight: 700;")
        self.glyph.setFixedWidth(46)
        self.glyph.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.glyph)
        col = QVBoxLayout()
        col.setSpacing(2)
        self.title = QLabel(title)
        self.title.setObjectName("dropTitle")
        self.sub = QLabel(subtitle)
        self.sub.setObjectName("dropPath")
        self.sub.setWordWrap(True)
        self.sub.setTextInteractionFlags(Qt.NoTextInteraction)
        col.addStretch()
        col.addWidget(self.title)
        col.addWidget(self.sub)
        col.addStretch()
        lay.addLayout(col, 1)
        self._default_sub = subtitle
        self._set_prop("hover", False)
        self._set_prop("filled", False)

    def _set_prop(self, name, val):
        self.setProperty(name, val)
        repolish(self)

    def path(self) -> str:
        return self._path

    def set_path(self, path: str):
        self._path = path or ""
        if self._path:
            self.sub.setText(os.path.basename(self._path) + "\n" + os.path.dirname(self._path))
            self.glyph.setText("●")
            self.glyph.setStyleSheet(f"font-size: 22pt; color: {PALETTE['ok']}; font-weight: 700;")
        else:
            self.sub.setText(self._default_sub)
            self.glyph.setText(self._glyph_default())
            self.glyph.setStyleSheet(f"font-size: 22pt; color: {PALETTE['accent']}; font-weight: 700;")
        self._set_prop("filled", bool(self._path))
        self.pathChanged.emit(self._path)

    def _glyph_default(self) -> str:
        return "+"

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._pick_cb()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._set_prop("hover", True)

    def dragLeaveEvent(self, e):
        self._set_prop("hover", False)

    def dropEvent(self, e):
        self._set_prop("hover", False)
        urls = e.mimeData().urls()
        if urls:
            p = urls[0].toLocalFile()
            if p:
                self.set_path(p)


def open_file_dialog(parent, title: str) -> str:
    path, _ = QFileDialog.getOpenFileName(
        parent, title, "", "Data (*.csv *.tsv *.txt *.xlsx *.xls *.json);;All files (*)")
    return path
