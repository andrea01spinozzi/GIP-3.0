"""Modello tabellare veloce basato su pandas (decine di migliaia di righe senza rallentamenti)."""
from __future__ import annotations

import pandas as pd
from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt
from PySide6.QtGui import QBrush, QColor


class DataFrameModel(QAbstractTableModel):
    """raw   = valori usati per l'ordinamento (numerici dove possibile)
    shown = testo visualizzato (già formattato)
    row_colors = lista opzionale di colori (hex) per riga, applicati al testo"""

    def __init__(self, raw: pd.DataFrame | None = None, shown: pd.DataFrame | None = None,
                 row_colors: list[str | None] | None = None, align_left: tuple[int, ...] = ()):
        super().__init__()
        self._align_left = align_left
        self.set_data(raw, shown, row_colors)

    def set_data(self, raw, shown=None, row_colors=None):
        self.beginResetModel()
        self._raw = raw.reset_index(drop=True) if raw is not None else pd.DataFrame()
        self._shown = (shown.reset_index(drop=True) if shown is not None else self._raw.astype(str))
        self._colors = list(row_colors) if row_colors is not None else [None] * len(self._raw)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._raw)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._raw.columns)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        r, c = index.row(), index.column()
        if role == Qt.DisplayRole:
            return str(self._shown.iat[r, c])
        if role == Qt.TextAlignmentRole:
            return int(Qt.AlignVCenter | (Qt.AlignLeft if c in self._align_left else Qt.AlignCenter))
        if role == Qt.ForegroundRole:
            col = self._colors[r] if r < len(self._colors) else None
            return QBrush(QColor(col)) if col else None
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal:
            return str(self._raw.columns[section])
        return None

    def sort(self, column, order=Qt.AscendingOrder):
        if column < 0 or column >= len(self._raw.columns) or self._raw.empty:
            return
        self.layoutAboutToBeChanged.emit()
        name = self._raw.columns[column]
        key = self._raw[name]
        num = pd.to_numeric(key, errors="coerce")
        if num.notna().sum() >= key.notna().sum() * 0.9 and num.notna().any():
            key = num
        else:
            key = key.astype(str).str.lower()
        order_idx = key.sort_values(ascending=(order == Qt.AscendingOrder), kind="stable", na_position="last").index
        self._raw = self._raw.loc[order_idx].reset_index(drop=True)
        self._shown = self._shown.loc[order_idx].reset_index(drop=True)
        if self._colors:
            self._colors = [self._colors[i] for i in order_idx]
        self.layoutChanged.emit()

    def gene_at(self, row: int, column: int = 0) -> str | None:
        """Testo mostrato nella cella (row, column), None se fuori range (utile per la colonna GeneID)."""
        if row < 0 or row >= len(self._shown) or column >= len(self._shown.columns):
            return None
        return str(self._shown.iat[row, column])

    def rows_as_text(self, rows, sep: str = "\t", header: bool = True) -> str:
        """Righe scelte come testo separato da tab (come appaiono a schermo), pronto da incollare in Excel."""
        rows = sorted({r for r in rows if 0 <= r < len(self._shown)})
        if not rows:
            return ""
        out = self._shown.iloc[rows]
        return out.to_csv(sep=sep, index=False, header=header)
