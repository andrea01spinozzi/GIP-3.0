"""Heatmap clusterizzata dei geni differenzialmente espressi — versione PySide6 per DEA Explorer.

Righe   = geni, ORDINATI DAL CLUSTERING GERARCHICO (dendrogramma a sinistra = ordine delle righe).
Colonne = campioni: raggruppati per condizione (clusterizzati dentro ogni gruppo), clusterizzati del tutto
          (dendrogramma in alto) oppure nell'ordine originale.
Extra   = barra di annotazione dei campioni (condizione o qualunque colonna dei metadati, stesse regole di
          colore della PCA) e striscia del log2FC accanto alle righe.

Novità rispetto alla versione Tkinter
-------------------------------------
* stesso tema di gui_qt.py (Card, Chip, Toast, ExportDialog con preset da rivista);
* il clustering gira in un thread: la finestra non si blocca e si aggiorna da sola (debounce) quando cambi
  un controllo; le opzioni "solo grafiche" (colormap, limite colore, dendrogramma, nomi) non rifanno il clustering
  e conservano lo zoom;
* zoom con la rotella (Ctrl = zoom sui campioni), pan/zoom dalla toolbar, tasto destro = menu contestuale;
* click su un gene = selezione (evidenziato in heatmap e nella tabella), doppio click = apri in "Gene counts";
* ricerca gene con autocompletamento, "zoom sul gene", copia dei geni visibili / dell'immagine negli appunti;
* scheda "Ordered table" sincronizzata con la heatmap (ordinabile, cliccabile);
* le preferenze (geometria, linkage, colormap...) vengono ricordate tra una sessione e l'altra;
* ctx["preset_genes"] (opzionale): lista di geni con cui aprire direttamente la heatmap in modalità "Custom".

Richiede scipy (clustering gerarchico). Usato da gui_qt.py:  hmap.HeatmapWindow(parent, ctx)
"""
from __future__ import annotations

import math
import re

import numpy as np
import pandas as pd
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.cm import ScalarMappable
from matplotlib.collections import LineCollection
from matplotlib.colors import to_rgb
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from PySide6.QtCore import QSettings, QStringListModel, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QCursor, QGuiApplication, QKeySequence, QShortcut
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QCompleter, QDoubleSpinBox, QFileDialog,
                               QFrame, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMainWindow, QMenu,
                               QMessageBox, QProgressBar, QPushButton, QScrollArea, QSizePolicy, QSpinBox,
                               QTableView, QTabWidget, QVBoxLayout, QWidget)

import gene_plots as gplot
import pca_coloring as pcol
from qt_models import DataFrameModel
from qt_plots import ExportDialog
from qt_theme import PALETTE, Card, Chip, Toast, field, shortcut_hint

try:
    from scipy.cluster import hierarchy as sch
    from scipy.spatial.distance import pdist
    HAS_SCIPY = True
except Exception:                       # pragma: no cover
    sch = pdist = None
    HAS_SCIPY = False

GENE_MODES = ["Significant genes (Setup cutoffs)", "Top N by padj", "Custom gene list"]
VALUE_MODES = ["Row z-score", "log2 expression"]
LINKAGES = ["average", "complete", "ward", "single"]
DISTANCES = ["euclidean", "correlation", "cityblock"]
COL_MODES = ["Group by condition", "Cluster all samples", "Original order"]
CMAPS = {"Red–Blue": "RdBu_r", "Purple–Orange": "PuOr_r", "Cool–Warm": "coolwarm",
         "Green–Magenta": "PiYG_r", "Viridis": "viridis", "Magma": "magma", "Inferno": "inferno"}
DEFAULT_CMAP = {VALUE_MODES[0]: "Red–Blue", VALUE_MODES[1]: "Viridis"}
MAX_GENE_LABELS = 70                    # i nomi delle righe compaiono quando ne sono visibili <= questo numero
MAX_SAMPLE_LABELS = 60
ZOOM_ROWS = 12                          # righe mostrate da "Zoom to gene"


# --------------------------------------------------------------------------- #
# Calcolo puro (identico alla versione Tkinter)
# --------------------------------------------------------------------------- #
def select_genes(ranked: pd.DataFrame, nm: pd.DataFrame, mode: str, n: int, custom: str,
                 padj_cut: float, lfc_cut: float):
    """Returns (DataFrame[GeneID, log2FoldChange, padj] , list_of_missing_custom_genes)."""
    df = ranked.copy()
    df["GeneID"] = df["GeneID"].astype(str)
    df["padj"] = pd.to_numeric(df["padj"], errors="coerce")
    df["log2FoldChange"] = pd.to_numeric(df["log2FoldChange"], errors="coerce")
    df = df.drop_duplicates("GeneID")
    present = set(nm.index)
    missing: list[str] = []

    if mode == GENE_MODES[2]:
        names = [g for g in re.split(r"[,\s;]+", custom or "") if g]
        rows = []
        for g in names:
            real = gplot.find_gene(nm, g)
            if real is None:
                missing.append(g)
                continue
            rows.append(real)
        rows = list(dict.fromkeys(rows))
        out = pd.DataFrame({"GeneID": rows})
        out = out.merge(df[["GeneID", "log2FoldChange", "padj"]], on="GeneID", how="left")
        return out, missing

    df = df[df["GeneID"].isin(present)]
    if mode == GENE_MODES[0]:
        df = df[(df["padj"] < padj_cut) & (df["log2FoldChange"].abs() >= lfc_cut)]
    df = df.dropna(subset=["padj"]).sort_values("padj")
    return df.head(int(n))[["GeneID", "log2FoldChange", "padj"]].reset_index(drop=True), missing


def link(X: np.ndarray, method: str, metric: str):
    """Linkage of the ROWS of X (None when fewer than 2 rows)."""
    if X.shape[0] < 2:
        return None
    if method == "ward":
        metric = "euclidean"            # ward è definito solo per distanze euclidee
    d = np.nan_to_num(pdist(X, metric=metric), nan=0.0, posinf=0.0)
    Z = sch.linkage(d, method=method)
    if X.shape[0] <= 2000:
        try:
            Z = sch.optimal_leaf_ordering(Z, d)     # foglie vicine = le più simili
        except Exception:
            pass
    return Z


def dendro_segments(Z):
    """(leaf_order, segments) with segments = [[(leaf_pos, height), ...], ...], leaf_pos in 0..n-1 units."""
    dd = sch.dendrogram(Z, no_plot=True)
    segs = [[((x - 5.0) / 10.0, y) for x, y in zip(ic, dc)] for ic, dc in zip(dd["icoord"], dd["dcoord"])]
    return list(dd["leaves"]), segs


def _natural_key(t):
    return [int(s) if s.isdigit() else s.lower() for s in re.split(r"(\d+)", str(t))]


def compute_heatmap(ctx: dict, o: dict) -> dict:
    """ctx: vedi HeatmapWindow. o: opzioni (vedi HeatmapWindow._options). Solleva ValueError (leggibile)."""
    if not HAS_SCIPY:
        raise ValueError("scipy is required for hierarchical clustering (pip install scipy).")
    nm = ctx["norm_mat"]
    nm = nm[~nm.index.duplicated()]
    cond_all: pd.Series = ctx["cond"]
    hi, lo = ctx.get("group_high"), ctx.get("group_low")
    notes: list[str] = []

    samples = [str(s) for s in nm.columns]
    if o["only_contrast"] and hi and lo:
        keep = [s for s in samples if cond_all.get(s) in (hi, lo)]
        if len(keep) >= 3:
            samples = keep
        else:
            notes.append("fewer than 3 samples in the contrast groups: all samples used")
    if len(samples) < 3:
        raise ValueError("At least 3 samples are needed to build the heatmap.")

    sel, missing = select_genes(ctx["ranked"], nm, o["gene_mode"], o["topn"], o["custom"],
                                ctx["padj"], ctx["lfc"])
    if missing:
        notes.append("not found: " + ", ".join(missing[:8]) + ("…" if len(missing) > 8 else ""))
    if sel.empty:
        raise ValueError("No genes to show with the current selection (try 'Top N by padj' "
                         "or looser cutoffs in the Setup tab).")

    X = nm.loc[sel["GeneID"], samples].astype(float).replace([np.inf, -np.inf], np.nan)
    ok = X.notna().all(axis=1)
    sd = X.std(axis=1, ddof=1)
    ok &= sd > 0
    if (~ok).any():
        notes.append(f"{int((~ok).sum())} genes dropped (constant or missing values)")
    X = X[ok]
    sel = sel.set_index("GeneID").loc[X.index]
    if len(X) < 3:
        raise ValueError("At least 3 genes with variable expression are needed to cluster.")

    Zs = X.sub(X.mean(axis=1), axis=0).div(X.std(axis=1, ddof=1), axis=0)      # z-score per riga
    zv = Zs.values

    # ---- geni: il clustering gerarchico decide l'ordine delle righe ------------------------------
    Zg = link(zv, o["linkage"], o["metric"])
    g_leaves, g_segs = dendro_segments(Zg)

    # ---- campioni ---------------------------------------------------------------------------------
    cond_s = cond_all.reindex(samples).fillna("NA").astype(str)
    Zc, c_segs, bounds = None, None, []
    if o["col_mode"] == COL_MODES[1]:
        Zc = link(zv.T, o["linkage"], o["metric"])
        c_leaves, c_segs = dendro_segments(Zc)
    elif o["col_mode"] == COL_MODES[0]:
        present = sorted(set(cond_s), key=_natural_key)
        order_groups = [g for g in (hi, lo) if g in present] + [g for g in present if g not in (hi, lo)]
        c_leaves = []
        for g in order_groups:
            idx = [k for k, s in enumerate(samples) if cond_s[s] == g]
            if len(idx) >= 3:
                Zi = link(zv[:, idx].T, o["linkage"], o["metric"])
                idx = [idx[k] for k in sch.leaves_list(Zi)]
            c_leaves += idx
            bounds.append(len(c_leaves))
        bounds = bounds[:-1]
    else:
        c_leaves = list(range(len(samples)))

    genes = [X.index[i] for i in g_leaves]
    ord_samples = [samples[k] for k in c_leaves]
    Xo = X.loc[genes, ord_samples]
    Zo = Zs.loc[genes, ord_samples]
    if o["values"] == VALUE_MODES[0]:
        D, cmap = Zo.values, "RdBu_r"
        vmin, vmax = -o["vlim"], o["vlim"]
        cb_label = "row z-score"
    else:
        D, cmap = Xo.values, "viridis"
        vmin, vmax = (float(np.percentile(D, 1)), float(np.percentile(D, 99)))
        cb_label = ctx.get("norm_label", "log2 expression")
    sel = sel.loc[genes]
    lfc = sel["log2FoldChange"].to_numpy(dtype=float)

    # ---- annotazione dei campioni -----------------------------------------------------------------
    ann = o["annotate"]
    spec = None
    if ann != pcol.DEFAULT_COLUMN and ctx.get("meta") is not None:
        try:
            spec = pcol.build_spec(pd.DataFrame({"SampleID": ord_samples}), ctx["meta"], ctx["sample_col"],
                                   ann, "Auto", False, "Red → Blue")
            if spec.get("n_unmatched"):
                notes.append(f"{spec['n_unmatched']} sample IDs not found in the metadata")
        except ValueError as e:
            notes.append(f"annotation by '{ann}' not possible: {e}")
    if spec is None:
        spec = pcol.condition_spec(pd.DataFrame({"condition": cond_all.astype(str).values}))
        spec["values"] = pd.Series(cond_s.loc[ord_samples].values)
    spec["values"] = pd.Series(np.asarray(spec["values"].values, dtype=object))

    return {"D": D, "X": Xo, "Z": Zo, "genes": genes, "samples": ord_samples,
            "cond": cond_s.loc[ord_samples].tolist(), "lfc": lfc, "padj": sel["padj"].to_numpy(dtype=float),
            "cmap": cmap, "vmin": vmin, "vmax": vmax, "cb_label": cb_label, "spec": spec,
            "g_segs": g_segs, "c_segs": c_segs, "Zc": Zc, "bounds": bounds, "notes": notes,
            "title": ctx.get("title", "")}


def ordered_table(d: dict) -> pd.DataFrame:
    """Geni in ordine di clustering con log2FC, padj e i valori mostrati per ogni campione."""
    out = pd.DataFrame({"GeneID": d["genes"], "cluster_order": range(1, len(d["genes"]) + 1),
                        "log2FoldChange": d["lfc"], "padj": d["padj"]})
    vals = pd.DataFrame(d["D"], columns=d["samples"])
    return pd.concat([out, vals], axis=1)


# --------------------------------------------------------------------------- #
# Disegno
# --------------------------------------------------------------------------- #
def _annotation_rgb(spec: dict):
    """(rgb array (1, n, 3), stringhe per l'hover)."""
    vals = spec["values"]
    n = len(vals)
    if spec["mode"] == "numeric":
        num = pd.to_numeric(vals, errors="coerce")
        rgb = np.zeros((1, n, 3))
        txt = []
        for k, v in enumerate(num):
            if pd.isna(v):
                rgb[0, k] = to_rgb(pcol.MISSING_COLOR)
                txt.append("n.a.")
            else:
                rgb[0, k] = spec["cmap"](spec["norm"](v))[:3]
                txt.append(f"{v:g}")
        return rgb, txt
    cmap = dict(spec["groups"])
    rgb = np.zeros((1, n, 3))
    txt = []
    for k, v in enumerate(vals):
        if pd.isna(v) or v not in cmap:
            rgb[0, k] = to_rgb(pcol.MISSING_COLOR)
            txt.append("n.a.")
        else:
            rgb[0, k] = to_rgb(cmap[v])
            txt.append(str(v))
    return rgb, txt


def render_heatmap(fig: Figure, d: dict, o: dict) -> dict:
    """Disegna tutto su `fig`; restituisce un dict di handle usato dalla finestra interattiva."""
    fig.clear()
    n_g, n_s = d["D"].shape
    show_gd = bool(o["gene_dendro"])
    show_cd = d["c_segs"] is not None
    gs = fig.add_gridspec(3, 3, width_ratios=[0.16 if show_gd else 0.001, 1, 0.035],
                          height_ratios=[0.14 if show_cd else 0.001, 0.04, 1],
                          left=0.02, right=0.79, top=0.92, bottom=0.14, wspace=0.012, hspace=0.012)
    ax_h = fig.add_subplot(gs[2, 1])
    ax_gd = fig.add_subplot(gs[2, 0], sharey=ax_h)
    ax_cd = fig.add_subplot(gs[0, 1], sharex=ax_h)
    ax_an = fig.add_subplot(gs[1, 1], sharex=ax_h)
    ax_l = fig.add_subplot(gs[2, 2], sharey=ax_h)

    im = ax_h.imshow(d["D"], aspect="auto", cmap=d["cmap"], vmin=d["vmin"], vmax=d["vmax"],
                     interpolation="nearest")
    for b in d["bounds"]:
        ax_h.axvline(b - 0.5, color="white", lw=2)

    # striscia del log2FC
    lfc = d["lfc"]
    lim = float(np.nanpercentile(np.abs(lfc), 98)) if np.isfinite(lfc).any() else 1.0
    lim = max(lim, 1e-6)
    im_l = ax_l.imshow(np.nan_to_num(lfc, nan=0.0)[:, None], aspect="auto", cmap="PuOr_r", vmin=-lim, vmax=lim,
                       interpolation="nearest")
    ax_l.set_xticks([])
    ax_l.set_title("log2FC", fontsize=7, pad=3)

    # dendrogramma dei geni (sinistra): il suo ordine delle foglie È l'ordine delle righe
    if show_gd:
        hmax = max(h for seg in d["g_segs"] for _, h in seg) or 1.0
        ax_gd.add_collection(LineCollection([[(h, p) for p, h in seg] for seg in d["g_segs"]],
                                            colors="#444444", linewidths=0.8))
        ax_gd.set_xlim(hmax * 1.03, 0)
    ax_gd.axis("off")

    # dendrogramma dei campioni (alto)
    if show_cd:
        hmax = max(h for seg in d["c_segs"] for _, h in seg) or 1.0
        ax_cd.add_collection(LineCollection([list(seg) for seg in d["c_segs"]], colors="#444444", linewidths=0.8))
        ax_cd.set_ylim(0, hmax * 1.03)
    ax_cd.axis("off")

    # barra di annotazione
    rgb, ann_txt = _annotation_rgb(d["spec"])
    ax_an.imshow(rgb, aspect="auto", interpolation="nearest")
    ax_an.axis("off")
    ax_an.text(-0.006, 0.5, d["spec"]["column"], transform=ax_an.transAxes, ha="right", va="center", fontsize=7)

    # limiti espliciti: prima riga in alto
    ax_h.set_xlim(-0.5, n_s - 0.5)
    ax_h.set_ylim(n_g - 0.5, -0.5)

    ax_h.tick_params(axis="y", left=False, labelleft=False)
    ax_h.tick_params(axis="x", length=2)
    ax_l.yaxis.tick_right()
    ax_l.tick_params(axis="y", length=2, labelleft=False, labelright=True)

    # scale colore + legenda (destra)
    cax = fig.add_axes([0.90, 0.14, 0.014, 0.17])
    fig.colorbar(im, cax=cax).set_label(d["cb_label"], fontsize=7)
    cax.tick_params(labelsize=7)
    cax2 = fig.add_axes([0.90, 0.38, 0.014, 0.17])
    fig.colorbar(im_l, cax=cax2).set_label("log2FC", fontsize=7)
    cax2.tick_params(labelsize=7)
    spec = d["spec"]
    if spec["mode"] == "numeric":
        cax3 = fig.add_axes([0.90, 0.62, 0.014, 0.17])
        fig.colorbar(ScalarMappable(norm=spec["norm"], cmap=spec["cmap"]), cax=cax3).set_label(
            spec["column"], fontsize=7)
        cax3.tick_params(labelsize=7)
    else:
        present = [(lab, c) for lab, c in spec["groups"] if (spec["values"] == lab).any()]
        if spec["values"].isna().any():
            present.append((pcol.MISSING_LABEL, pcol.MISSING_COLOR))
        handles = [Line2D([], [], marker="s", ls="", markersize=8, markerfacecolor=c, markeredgecolor="none",
                          label=lab) for lab, c in present]
        fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.88, 0.93), frameon=False,
                   fontsize=7, title=spec["column"], title_fontsize=8)

    fig.text(0.02, 0.965, d["title"], fontsize=11, fontweight="bold", ha="left", va="center")

    h = {"ax_h": ax_h, "ax_l": ax_l, "ax_an": ax_an, "ax_gd": ax_gd, "ax_cd": ax_cd, "n_g": n_g, "n_s": n_s,
         "genes": d["genes"], "samples": d["samples"], "ann_txt": ann_txt,
         "gene_labels": bool(o["gene_labels"]), "busy": False,
         # cursore dell'hover (nero) e selezione (accento) su heatmap e striscia log2FC
         "cursor": Rectangle((-0.5, -0.5), n_s, 1, fill=False, ec="black", lw=1.2, visible=False, zorder=5),
         "sel": Rectangle((-0.5, -0.5), n_s, 1, fill=False, ec=PALETTE["accent"], lw=2.2, visible=False, zorder=6),
         "sel_l": Rectangle((-0.5, -0.5), 1, 1, fill=False, ec=PALETTE["accent"], lw=2.2, visible=False, zorder=6)}
    ax_h.add_patch(h["cursor"])
    ax_h.add_patch(h["sel"])
    ax_l.add_patch(h["sel_l"])
    ax_h.callbacks.connect("ylim_changed", lambda _a: update_ticks(h))
    ax_h.callbacks.connect("xlim_changed", lambda _a: update_ticks(h))
    update_ticks(h)
    return h


def update_ticks(h: dict):
    """I nomi di geni / campioni compaiono solo quando ce ne sono pochi in vista (zoom per leggerli)."""
    if h["busy"]:
        return
    h["busy"] = True
    try:
        ax_h, ax_l = h["ax_h"], h["ax_l"]
        y0, y1 = sorted(ax_h.get_ylim())
        lo, hi = max(0, math.ceil(y0)), min(h["n_g"] - 1, math.floor(y1))
        rows = list(range(lo, hi + 1)) if (h["gene_labels"] and 0 < hi - lo + 1 <= MAX_GENE_LABELS) else []
        ax_l.set_yticks(rows)
        ax_l.set_yticklabels([h["genes"][i] for i in rows], fontsize=8 if len(rows) <= 35 else 6)
        x0, x1 = sorted(ax_h.get_xlim())
        lo, hi = max(0, math.ceil(x0)), min(h["n_s"] - 1, math.floor(x1))
        cols = list(range(lo, hi + 1)) if 0 < hi - lo + 1 <= MAX_SAMPLE_LABELS else []
        ax_h.set_xticks(cols)
        ax_h.set_xticklabels([h["samples"][j] for j in cols], rotation=90, fontsize=7 if len(cols) <= 35 else 5)
    finally:
        h["busy"] = False


# --------------------------------------------------------------------------- #
# Thread di calcolo
# --------------------------------------------------------------------------- #
_ALIVE: set = set()          # riferimenti ai thread in corsa (evita il crash se la finestra si chiude prima)


class _ClusterJob(QThread):
    done = Signal(int, object)
    failed = Signal(int, str)

    def __init__(self, seq: int, ctx: dict, o: dict):
        super().__init__()                  # volutamente senza parent
        self.seq, self.ctx, self.o = seq, ctx, o

    def run(self):
        try:
            data = compute_heatmap(self.ctx, self.o)
        except Exception as e:  # noqa: BLE001
            self.failed.emit(self.seq, str(e))
            return
        self.done.emit(self.seq, data)


# --------------------------------------------------------------------------- #
# Widget grafico (figura + toolbar), compatibile con ExportDialog di qt_plots
# --------------------------------------------------------------------------- #
class HeatmapCanvas(QWidget):
    def __init__(self):
        super().__init__()
        self.figure = Figure(figsize=(11, 8), dpi=100)
        self.figure.patch.set_facecolor("white")
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.canvas.setMinimumHeight(360)
        self.toolbar = NavigationToolbar2QT(self.canvas, self)
        self.toolbar.setStyleSheet(
            "QToolBar { background: transparent; border: none; spacing: 2px; }"
            "QToolButton { border: none; border-radius: 6px; padding: 5px; }"
            f"QToolButton:hover {{ background: {PALETTE['accent_pale']}; }}"
            f"QToolButton:checked {{ background: {PALETTE['accent_pale']}; border: 1px solid {PALETTE['accent']}; }}"
            f"QLabel {{ color: {PALETTE['muted']}; font-size: 8.5pt; }}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.canvas)


# --------------------------------------------------------------------------- #
# Finestra
# --------------------------------------------------------------------------- #
class HeatmapWindow(QMainWindow):
    """ctx: norm_mat, norm_label, ranked (GeneID/log2FoldChange/padj), cond (Series SampleID->condizione),
    group_high, group_low, padj, lfc (soglie), title, meta (DataFrame|None), sample_col,
    on_gene (callable|None), preset_genes (lista|None, opzionale)."""

    PREF_KEYS = ("gene_mode", "topn", "values", "linkage", "metric", "col_mode", "cmap", "vlim",
                 "gene_dendro", "gene_labels")

    def __init__(self, master, ctx: dict):
        super().__init__(master)
        self.ctx = ctx
        self.setWindowTitle(f"Heatmap · {ctx.get('title', '')}")
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.resize(1400, 900)
        self.setMinimumSize(1000, 660)
        self._data: dict | None = None
        self._h: dict | None = None
        self._seq = 0
        self._busy = False
        self._dirty = False
        self._loading = True
        self._sel_gene: str | None = None
        self._custom_applied = ""
        self._last_cell: tuple[int, int] | None = None
        self._settings = QSettings("DEAExplorer", "Heatmap")

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(20, 14, 20, 8)
        outer.setSpacing(10)
        outer.addLayout(self._build_head())

        row = QHBoxLayout()
        row.setSpacing(16)
        row.addWidget(self._build_main(), 1)
        row.addWidget(self._build_inspector_scroll())
        outer.addLayout(row, 1)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setFixedWidth(120)
        self.progress.setVisible(False)
        self.statusBar().addPermanentWidget(self.progress)
        self.toast = Toast(root)

        self._t_compute = QTimer(self)
        self._t_compute.setSingleShot(True)
        self._t_compute.setInterval(380)
        self._t_compute.timeout.connect(self._recompute)
        self._t_render = QTimer(self)
        self._t_render.setSingleShot(True)
        self._t_render.setInterval(90)
        self._t_render.timeout.connect(self._rerender)

        self._connect_signals()
        self._build_shortcuts()
        self._load_prefs()
        preset = [str(g) for g in (ctx.get("preset_genes") or [])]
        if preset:
            self.c_mode.setCurrentText(GENE_MODES[2])
            self.c_custom.setText(", ".join(preset))
        self._sync_enabled()
        self._loading = False
        self.statusBar().showMessage("Computing clustering…")
        QTimer.singleShot(30, self._recompute)

    # ------------------------------------------------------------------ costruzione UI
    def _build_head(self) -> QHBoxLayout:
        head = QHBoxLayout()
        box = QVBoxLayout()
        box.setSpacing(2)
        t = QLabel("Clustered heatmap")
        t.setObjectName("h1")
        self.subtitle = QLabel(self.ctx.get("title", ""))
        self.subtitle.setObjectName("muted")
        box.addWidget(t)
        box.addWidget(self.subtitle)
        head.addLayout(box)
        head.addStretch()
        self.chip = Chip("Computing…")
        head.addWidget(self.chip, alignment=Qt.AlignVCenter)
        return head

    def _build_main(self) -> QWidget:
        self.tabs = QTabWidget()

        # --- scheda heatmap
        page = QWidget()
        pv = QVBoxLayout(page)
        pv.setContentsMargins(10, 10, 10, 8)
        pv.setSpacing(8)
        self.hm = HeatmapCanvas()
        self.fig = self.hm.figure
        self.canvas = self.hm.canvas
        self.toolbar = self.hm.toolbar

        top = QHBoxLayout()
        top.setSpacing(8)
        top.addWidget(self.toolbar, 1)
        self.find = QLineEdit()
        self.find.setPlaceholderText(shortcut_hint("Find gene…  (Ctrl+F)"))
        self.find.setClearButtonEnabled(True)
        self.find.setMinimumWidth(220)
        self.find.setToolTip("Type a gene of this heatmap and press Enter: it is selected and zoomed in.")
        self._completer_model = QStringListModel([])
        comp = QCompleter(self._completer_model, self)
        comp.setCaseSensitivity(Qt.CaseInsensitive)
        comp.setFilterMode(Qt.MatchContains)
        self.find.setCompleter(comp)
        self.btn_reset = QPushButton("Reset view")
        self.btn_reset.setToolTip(shortcut_hint("Back to the full heatmap (Ctrl+0)."))
        top.addWidget(self.find)
        top.addWidget(self.btn_reset)
        pv.addLayout(top)

        frame = QFrame()
        frame.setObjectName("card")
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(6, 6, 6, 6)
        fl.addWidget(self.hm)
        pv.addWidget(frame, 1)

        self.hover = QLabel("Hover for details · click = select gene · double click = open in 'Gene counts' · "
                            + shortcut_hint("wheel = zoom rows (Ctrl+wheel = samples) · right click = menu"))
        self.hover.setObjectName("cardHint")
        self.hover.setWordWrap(True)
        self.hover.setStyleSheet(f"background: {PALETTE['accent_pale_2']}; border-radius: 8px; padding: 8px 12px;")
        pv.addWidget(self.hover)
        self.tabs.addTab(page, "Heatmap")

        # --- scheda tabella ordinata
        tpage = QWidget()
        tv = QVBoxLayout(tpage)
        tv.setContentsMargins(10, 10, 10, 8)
        tv.setSpacing(8)
        self.t_info = QLabel("Genes in clustering order (the displayed values are z-scores or log2 expression). "
                             "Click a row to select the gene in the heatmap; double click to open it in 'Gene counts'.")
        self.t_info.setObjectName("cardHint")
        self.t_info.setWordWrap(True)
        tv.addWidget(self.t_info)
        self.model = DataFrameModel(pd.DataFrame(columns=["GeneID", "cluster_order", "log2FoldChange", "padj"]),
                                    align_left=(0,))
        self.table = QTableView()
        self.table.setModel(self.model)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QTableView.NoEditTriggers)
        self.table.setSortingEnabled(True)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSortIndicatorShown(True)
        self.table.horizontalHeader().setSortIndicator(-1, Qt.AscendingOrder)
        self.table.setShowGrid(False)
        tv.addWidget(self.table, 1)
        self.tabs.addTab(tpage, "Ordered table")
        return self.tabs

    def _build_inspector_scroll(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 6, 0)
        lay.setSpacing(12)

        # --- gene selezionato
        c_sel = Card("Selected gene", "Click a row of the heatmap or of the table.")
        self.sel_name = QLabel("—")
        self.sel_name.setStyleSheet(f"font-size: 13pt; font-weight: 700; color: {PALETTE['ink']};")
        self.sel_info = QLabel("")
        self.sel_info.setObjectName("muted")
        self.sel_info.setWordWrap(True)
        self.btn_open = QPushButton("Open in Gene counts")
        self.btn_open.setEnabled(False)
        self.btn_zoom = QPushButton("Zoom to gene")
        self.btn_zoom.setEnabled(False)
        c_sel.body().addWidget(self.sel_name)
        c_sel.body().addWidget(self.sel_info)
        r = QHBoxLayout()
        r.addWidget(self.btn_zoom)
        r.addWidget(self.btn_open)
        c_sel.body().addLayout(r)
        lay.addWidget(c_sel)

        # --- scelta dei geni
        c_genes = Card("Genes")
        self.c_mode = QComboBox()
        self.c_mode.addItems(GENE_MODES)
        self.c_topn = QSpinBox()
        self.c_topn.setRange(3, 2000)
        self.c_topn.setValue(50)
        self.c_custom = QLineEdit()
        self.c_custom.setPlaceholderText("TP53, MYC, EGFR")
        self.c_contrast = QCheckBox("Only samples of the contrast groups")
        self.c_contrast.setChecked(bool(self.ctx.get("group_high") and self.ctx.get("group_low")))
        self.c_contrast.setVisible(bool(self.ctx.get("group_high") and self.ctx.get("group_low")))
        c_genes.body().addWidget(field("Selection", self.c_mode))
        c_genes.body().addWidget(field("N max genes", self.c_topn))
        c_genes.body().addWidget(field("Custom list", self.c_custom, "Separated by comma, space or ';'."))
        c_genes.body().addWidget(self.c_contrast)
        lay.addWidget(c_genes)

        # --- clustering
        c_cl = Card("Clustering")
        self.c_values = QComboBox()
        self.c_values.addItems(VALUE_MODES)
        self.c_link = QComboBox()
        self.c_link.addItems(LINKAGES)
        self.c_metric = QComboBox()
        self.c_metric.addItems(DISTANCES)
        self.c_cols = QComboBox()
        self.c_cols.addItems(COL_MODES)
        c_cl.body().addWidget(field("Values", self.c_values))
        rr = QHBoxLayout()
        rr.addWidget(field("Linkage", self.c_link))
        rr.addWidget(field("Distance", self.c_metric))
        c_cl.body().addLayout(rr)
        c_cl.body().addWidget(field("Samples", self.c_cols))
        lay.addWidget(c_cl)

        # --- annotazione
        c_an = Card("Sample annotation")
        self.c_annot = QComboBox()
        cols = [pcol.DEFAULT_COLUMN]
        if self.ctx.get("meta") is not None:
            cols += [str(c) for c in self.ctx["meta"].columns]
        self.c_annot.addItems(cols)
        c_an.body().addWidget(field("Colour bar by", self.c_annot,
                                    "Condition or any metadata column (same colouring rules as the PCA)."))
        lay.addWidget(c_an)

        # --- aspetto (solo grafico: niente ricalcolo, zoom conservato)
        c_ap = Card("Appearance", "Changes here keep your zoom.")
        self.c_cmap = QComboBox()
        self.c_cmap.addItems(list(CMAPS))
        self.c_cmap.setCurrentText(DEFAULT_CMAP[VALUE_MODES[0]])
        self.c_vlim = QDoubleSpinBox()
        self.c_vlim.setRange(0.5, 5.0)
        self.c_vlim.setSingleStep(0.5)
        self.c_vlim.setValue(2.0)
        self.c_gdendro = QCheckBox("Gene dendrogram")
        self.c_gdendro.setChecked(True)
        self.c_glabels = QCheckBox("Gene names (when zoomed in)")
        self.c_glabels.setChecked(True)
        c_ap.body().addWidget(field("Colour map", self.c_cmap))
        c_ap.body().addWidget(field("Colour limit ± (z-score)", self.c_vlim))
        c_ap.body().addWidget(self.c_gdendro)
        c_ap.body().addWidget(self.c_glabels)
        lay.addWidget(c_ap)

        # --- azioni
        c_ac = Card("Actions")
        self.btn_update = QPushButton("Recompute now")
        self.btn_update.setObjectName("primary")
        self.btn_update.setToolTip("The heatmap updates by itself when you change a setting (F5 forces it).")
        self.btn_export = QPushButton("Export figure…")
        self.btn_export.setToolTip(shortcut_hint("PNG / PDF / SVG / TIFF / EPS with journal size presets (Ctrl+E)."))
        self.btn_csv = QPushButton("Export ordered table CSV…")
        self.btn_copy_img = QPushButton("Copy image")
        self.btn_copy_genes = QPushButton("Copy visible genes")
        self.btn_copy_genes.setToolTip("Gene names currently in view, one per line — ready to paste elsewhere.")
        c_ac.body().addWidget(self.btn_update)
        c_ac.body().addWidget(self.btn_export)
        c_ac.body().addWidget(self.btn_csv)
        r2 = QHBoxLayout()
        r2.addWidget(self.btn_copy_img)
        r2.addWidget(self.btn_copy_genes)
        c_ac.body().addLayout(r2)
        lay.addWidget(c_ac)
        lay.addStretch()

        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setWidget(w)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setFixedWidth(322)
        return sa

    def _build_shortcuts(self):
        QShortcut(QKeySequence("F5"), self, activated=self._recompute)
        QShortcut(QKeySequence("Ctrl+F"), self, activated=lambda: (self.tabs.setCurrentIndex(0),
                                                                    self.find.setFocus(), self.find.selectAll()))
        QShortcut(QKeySequence("Ctrl+E"), self, activated=self._export_figure)
        QShortcut(QKeySequence("Ctrl+0"), self, activated=self._reset_view)
        QShortcut(QKeySequence("Esc"), self, activated=lambda: self._select_gene(None))

    def _connect_signals(self):
        # opzioni che richiedono il ricalcolo del clustering
        for c in (self.c_mode, self.c_values, self.c_link, self.c_metric, self.c_cols, self.c_annot):
            c.currentIndexChanged.connect(self._on_compute_option)
        self.c_topn.valueChanged.connect(self._on_compute_option)
        self.c_contrast.toggled.connect(self._on_compute_option)
        self.c_custom.editingFinished.connect(self._on_custom_finished)
        self.c_values.currentTextChanged.connect(self._on_values_mode)
        self.c_link.currentTextChanged.connect(lambda *_: self._sync_enabled())
        self.c_mode.currentTextChanged.connect(lambda *_: self._sync_enabled())
        # opzioni solo grafiche
        self.c_cmap.currentIndexChanged.connect(self._on_view_option)
        self.c_vlim.valueChanged.connect(self._on_view_option)
        self.c_gdendro.toggled.connect(self._on_view_option)
        self.c_glabels.toggled.connect(self._on_view_option)
        # azioni
        self.btn_update.clicked.connect(self._recompute)
        self.btn_export.clicked.connect(self._export_figure)
        self.btn_csv.clicked.connect(self._export_table)
        self.btn_copy_img.clicked.connect(self._copy_image)
        self.btn_copy_genes.clicked.connect(self._copy_visible_genes)
        self.btn_reset.clicked.connect(self._reset_view)
        self.btn_zoom.clicked.connect(lambda: self._zoom_to_gene(self._sel_gene))
        self.btn_open.clicked.connect(lambda: self._open_gene(self._sel_gene))
        self.find.returnPressed.connect(self._on_find)
        self.find.completer().activated.connect(lambda _t: self._on_find())
        # interazione mpl
        self.canvas.mpl_connect("motion_notify_event", self._on_move)
        self.canvas.mpl_connect("axes_leave_event", self._on_leave)
        self.canvas.mpl_connect("button_press_event", self._on_click)
        self.canvas.mpl_connect("scroll_event", self._on_scroll)
        # tabella
        self.table.clicked.connect(self._on_table_click)
        self.table.doubleClicked.connect(lambda idx: self._open_gene(self._table_gene(idx.row())))

    # ------------------------------------------------------------------ stato dei controlli
    def _sync_enabled(self):
        custom = self.c_mode.currentText() == GENE_MODES[2]
        self.c_custom.setEnabled(custom)
        self.c_topn.setEnabled(not custom)
        ward = self.c_link.currentText() == "ward"
        self.c_metric.setEnabled(not ward)
        self.c_metric.setToolTip("Ward linkage is only defined for euclidean distances." if ward else "")

    def _on_values_mode(self, text: str):
        """Cambiando 'Values' la colormap torna al default sensato (divergente per z-score, sequenziale per log2)."""
        if self._loading:
            return
        self.c_cmap.blockSignals(True)
        self.c_cmap.setCurrentText(DEFAULT_CMAP.get(text, "Viridis"))
        self.c_cmap.blockSignals(False)
        self.c_vlim.setEnabled(text == VALUE_MODES[0])

    def _on_compute_option(self, *_):
        if self._loading:
            return
        self._t_compute.start()

    def _on_custom_finished(self):
        if self._loading or self.c_mode.currentText() != GENE_MODES[2]:
            return
        if self.c_custom.text() != self._custom_applied:      # editingFinished scatta anche a testo invariato
            self._t_compute.start()

    def _on_view_option(self, *_):
        if self._loading:
            return
        self._t_render.start()

    def _options(self) -> dict:
        return {"gene_mode": self.c_mode.currentText(), "topn": max(3, self.c_topn.value()),
                "custom": self.c_custom.text(), "values": self.c_values.currentText(),
                "linkage": self.c_link.currentText(), "metric": self.c_metric.currentText(),
                "col_mode": self.c_cols.currentText(), "annotate": self.c_annot.currentText(),
                "only_contrast": self.c_contrast.isChecked() and self.c_contrast.isVisible(),
                "gene_dendro": self.c_gdendro.isChecked(), "gene_labels": self.c_glabels.isChecked(),
                "vlim": max(0.1, self.c_vlim.value())}

    # ------------------------------------------------------------------ calcolo (thread)
    def _recompute(self):
        self._t_compute.stop()
        if self._busy:
            self._dirty = True                  # rifà il calcolo appena finisce quello in corso
            return
        self._busy, self._dirty = True, False
        self._seq += 1
        o = self._options()
        self._custom_applied = o["custom"]
        job = _ClusterJob(self._seq, self.ctx, o)
        _ALIVE.add(job)
        job.finished.connect(lambda j=job: _ALIVE.discard(j))
        job.done.connect(self._on_done)
        job.failed.connect(self._on_failed)
        self.progress.setVisible(True)
        self.chip.set_state("idle", "Computing…")
        job.start()

    def _finish_job(self) -> bool:
        self._busy = False
        self.progress.setVisible(False)
        if self._dirty:
            QTimer.singleShot(0, self._recompute)
            return True
        return False

    def _on_failed(self, seq: int, msg: str):
        if self._finish_job():
            return
        self.chip.set_state("err", "Cannot build heatmap")
        self.statusBar().showMessage(f"Warning: {msg}")
        self.subtitle.setText(f"Warning: {msg}")
        self.subtitle.setWordWrap(True)

    def _on_done(self, seq: int, data: dict):
        if self._finish_job():
            return
        self._data = data
        self._rerender(keep_view=False)
        self._fill_table()
        self._completer_model.setStringList([str(g) for g in data["genes"]])
        n_g, n_s = data["D"].shape
        o = self._options()
        metric = "euclidean" if o["linkage"] == "ward" else o["metric"]
        note = (f"{n_g} genes × {n_s} samples · rows ordered by hierarchical clustering "
                f"({o['linkage']}, {metric}, on row z-scores)")
        if data["notes"]:
            note += " · " + " · ".join(data["notes"])
        self.chip.set_state("ok", f"{n_g} genes × {n_s} samples")
        self.subtitle.setText(self.ctx.get("title", ""))
        self.statusBar().showMessage(note)
        self.hover.setToolTip(note)

    # ------------------------------------------------------------------ disegno
    def _view_data(self) -> dict:
        """Copia dei dati con le opzioni grafiche applicate (nessun ricalcolo del clustering)."""
        d = dict(self._data)
        o = self._options()
        cmap = CMAPS.get(self.c_cmap.currentText(), d["cmap"])
        d["cmap"] = cmap
        if o["values"] == VALUE_MODES[0]:
            d["vmin"], d["vmax"] = -o["vlim"], o["vlim"]
        return d

    def _rerender(self, keep_view: bool = True):
        self._t_render.stop()
        if self._data is None:
            return
        prev = None
        if keep_view and self._h is not None:
            prev = (self._h["ax_h"].get_xlim(), self._h["ax_h"].get_ylim())
        self._h = render_heatmap(self.fig, self._view_data(), self._options())
        self.toolbar.update()                    # nuova "home" per la cronologia zoom/pan
        if prev is not None:
            self.toolbar.push_current()
            self._h["ax_h"].set_xlim(prev[0])
            self._h["ax_h"].set_ylim(prev[1])
            self.toolbar.push_current()
        self._last_cell = None
        if self._sel_gene is not None:
            self._select_gene(self._sel_gene, quiet=True)
        self.canvas.draw_idle()

    def _reset_view(self):
        h = self._h
        if h is None:
            return
        h["ax_h"].set_xlim(-0.5, h["n_s"] - 0.5)
        h["ax_h"].set_ylim(h["n_g"] - 0.5, -0.5)
        self.toolbar.push_current()
        self.canvas.draw_idle()

    # ------------------------------------------------------------------ selezione / zoom
    def _gene_index(self, gene: str | None) -> int | None:
        if gene is None or self._data is None:
            return None
        genes = self._data["genes"]
        if gene in genes:
            return genes.index(gene)
        low = str(gene).lower()
        for i, g in enumerate(genes):
            if str(g).lower() == low:
                return i
        return None

    def _select_gene(self, gene: str | None, zoom: bool = False, quiet: bool = False):
        h, d = self._h, self._data
        i = self._gene_index(gene)
        if h is None or d is None or i is None:
            self._sel_gene = None
            if h is not None:
                h["sel"].set_visible(False)
                h["sel_l"].set_visible(False)
                self.canvas.draw_idle()
            self.sel_name.setText("—")
            self.sel_info.setText("")
            self.btn_zoom.setEnabled(False)
            self.btn_open.setEnabled(False)
            self.table.clearSelection()
            return
        self._sel_gene = d["genes"][i]
        h["sel"].set_y(i - 0.5)
        h["sel"].set_visible(True)
        h["sel_l"].set_y(i - 0.5)
        h["sel_l"].set_visible(True)
        self.sel_name.setText(str(self._sel_gene))
        padj = d["padj"][i]
        self.sel_info.setText(f"log2FC {d['lfc'][i]:+.2f}  ·  padj {padj:.2g}  ·  cluster position {i + 1}/{h['n_g']}"
                              if np.isfinite(padj) else
                              f"log2FC {d['lfc'][i]:+.2f}  ·  cluster position {i + 1}/{h['n_g']}")
        self.btn_zoom.setEnabled(True)
        self.btn_open.setEnabled(callable(self.ctx.get("on_gene")))
        self._select_table_row(self._sel_gene)
        if zoom:
            self._zoom_to_gene(self._sel_gene)
        else:
            self.canvas.draw_idle()

    def _zoom_to_gene(self, gene: str | None):
        h = self._h
        i = self._gene_index(gene)
        if h is None or i is None:
            return
        lo = max(-0.5, i - ZOOM_ROWS / 2 - 0.5)
        hi = min(h["n_g"] - 0.5, lo + ZOOM_ROWS)
        lo = max(-0.5, hi - ZOOM_ROWS)
        h["ax_h"].set_ylim(hi, lo)
        self.toolbar.push_current()
        self.canvas.draw_idle()

    def _on_find(self):
        text = self.find.text().strip()
        if not text:
            return
        i = self._gene_index(text)
        if i is None:
            self.toast.show_message(f"'{text}' is not in this heatmap")
            self._place_toast()
            return
        self.tabs.setCurrentIndex(0)
        self._select_gene(self._data["genes"][i], zoom=True)

    def _open_gene(self, gene: str | None):
        cb = self.ctx.get("on_gene")
        if gene and callable(cb):
            cb(str(gene))

    # ------------------------------------------------------------------ tabella
    def _fill_table(self):
        d = self._data
        raw = ordered_table(d)
        shown = pd.DataFrame({"GeneID": raw["GeneID"].astype(str),
                              "cluster_order": raw["cluster_order"].astype(int).astype(str),
                              "log2FoldChange": raw["log2FoldChange"].map(lambda v: "" if pd.isna(v) else f"{v:+.3f}"),
                              "padj": raw["padj"].map(lambda v: "" if pd.isna(v) else f"{v:.2e}")})
        for s in d["samples"]:
            shown[s] = raw[s].map(lambda v: f"{v:.2f}")
        colors = [PALETTE["up"] if (pd.notna(v) and v > 0) else PALETTE["down"] if (pd.notna(v) and v < 0)
                  else PALETTE["muted"] for v in raw["log2FoldChange"]]
        self.model.set_data(raw, shown, colors)
        if self._sel_gene:
            self._select_table_row(self._sel_gene)

    def _table_gene(self, row: int) -> str | None:
        if row < 0 or row >= self.model.rowCount():
            return None
        return self.model.data(self.model.index(row, 0))

    def _select_table_row(self, gene: str | None):
        if gene is None:
            return
        for r in range(self.model.rowCount()):
            if self._table_gene(r) == gene:
                self.table.blockSignals(True)
                self.table.selectRow(r)
                self.table.blockSignals(False)
                self.table.scrollTo(self.model.index(r, 0), QAbstractItemView.PositionAtCenter)
                return

    def _on_table_click(self, idx):
        g = self._table_gene(idx.row())
        if g:
            self._select_gene(g)

    # ------------------------------------------------------------------ interazione mpl
    def _cell(self, ev):
        if self._h is None or ev.xdata is None or ev.ydata is None:
            return None
        return int(round(ev.ydata)), int(round(ev.xdata))

    def _on_move(self, ev):
        h, d = self._h, self._data
        if h is None or d is None or ev.inaxes is None:
            return
        c = self._cell(ev)
        if c is None:
            return
        i, j = c
        if ev.inaxes is h["ax_h"] and 0 <= i < h["n_g"] and 0 <= j < h["n_s"]:
            self.hover.setText(f"<b>{d['genes'][i]}</b> &nbsp;|&nbsp; {d['samples'][j]} ({d['cond'][j]}) &nbsp;|&nbsp; "
                               f"log2 expr {d['X'].iat[i, j]:.2f} &nbsp;|&nbsp; z = {d['Z'].iat[i, j]:+.2f} "
                               f"&nbsp;|&nbsp; log2FC {d['lfc'][i]:+.2f} &nbsp;|&nbsp; padj {d['padj'][i]:.2g}")
            cur = h["cursor"]
            if not cur.get_visible() or self._last_cell != (i, 0):
                cur.set_y(i - 0.5)
                cur.set_visible(True)
                self._last_cell = (i, 0)
                self.canvas.draw_idle()
        elif ev.inaxes is h["ax_l"] and 0 <= i < h["n_g"]:
            self.hover.setText(f"<b>{d['genes'][i]}</b> &nbsp;|&nbsp; log2FC {d['lfc'][i]:+.2f} "
                               f"&nbsp;|&nbsp; padj {d['padj'][i]:.2g}")
        elif ev.inaxes is h["ax_an"] and 0 <= j < h["n_s"]:
            self.hover.setText(f"<b>{d['samples'][j]}</b> &nbsp;|&nbsp; {d['spec']['column']}: {h['ann_txt'][j]}")

    def _on_leave(self, _ev):
        h = self._h
        if h is not None and h["cursor"].get_visible():
            h["cursor"].set_visible(False)
            self._last_cell = None
            self.canvas.draw_idle()

    def _gene_at(self, ev) -> str | None:
        h, d = self._h, self._data
        if h is None or d is None or ev.inaxes not in (h["ax_h"], h["ax_l"]):
            return None
        c = self._cell(ev)
        if c is None or not (0 <= c[0] < h["n_g"]):
            return None
        return d["genes"][c[0]]

    def _on_click(self, ev):
        if self._h is None or self.toolbar.mode:        # zoom/pan della toolbar attivi: non interferire
            return
        gene = self._gene_at(ev)
        if ev.button == 3:
            self._context_menu(gene)
            return
        if ev.button != 1 or gene is None:
            return
        if ev.dblclick:
            self._open_gene(gene)
        else:
            self._select_gene(gene)

    def _context_menu(self, gene: str | None):
        m = QMenu(self)
        if gene:
            m.addAction(f"Select {gene}", lambda: self._select_gene(gene))
            m.addAction(f"Zoom to {gene}", lambda: (self._select_gene(gene), self._zoom_to_gene(gene)))
            a = m.addAction(f"Open {gene} in Gene counts", lambda: self._open_gene(gene))
            a.setEnabled(callable(self.ctx.get("on_gene")))
            m.addAction(f"Copy '{gene}'", lambda: QGuiApplication.clipboard().setText(str(gene)))
            m.addSeparator()
        m.addAction("Copy visible genes", self._copy_visible_genes)
        m.addAction("Copy image", self._copy_image)
        m.addAction("Reset view", self._reset_view)
        m.exec(QCursor.pos())

    @staticmethod
    def _zoomed(lo, hi, center, f, full_lo, full_hi):
        new_lo, new_hi = center - (center - lo) * f, center + (hi - center) * f
        if new_hi - new_lo >= full_hi - full_lo:
            return full_lo, full_hi
        if new_hi - new_lo < 3 and f < 1:
            return lo, hi
        if new_lo < full_lo:
            new_hi += full_lo - new_lo
            new_lo = full_lo
        if new_hi > full_hi:
            new_lo -= new_hi - full_hi
            new_hi = full_hi
        return new_lo, new_hi

    def _on_scroll(self, ev):
        h = self._h
        if h is None or ev.inaxes is None or ev.xdata is None or ev.ydata is None:
            return
        if ev.inaxes not in (h["ax_h"], h["ax_l"], h["ax_gd"], h["ax_cd"], h["ax_an"]):
            return
        f = 0.8 if ev.step > 0 else 1.25
        ax = h["ax_h"]
        # matplotlib reports the Cmd key as "cmd" and the physical Control key as "control" on macOS: accept both
        k = str(ev.key) if ev.key is not None else ""
        along_x = ("control" in k or "cmd" in k) or ev.inaxes in (h["ax_cd"], h["ax_an"])
        if along_x:
            lo, hi = sorted(ax.get_xlim())
            lo, hi = self._zoomed(lo, hi, ev.xdata, f, -0.5, h["n_s"] - 0.5)
            ax.set_xlim(lo, hi)
        else:
            lo, hi = sorted(ax.get_ylim())
            lo, hi = self._zoomed(lo, hi, ev.ydata, f, -0.5, h["n_g"] - 0.5)
            ax.set_ylim(hi, lo)                          # asse invertito: prima riga in alto
        self.canvas.draw_idle()

    # ------------------------------------------------------------------ appunti / export
    def _place_toast(self):
        c = self.centralWidget()
        self.toast.move(c.width() - self.toast.width() - 24, c.height() - self.toast.height() - 40)

    def _say(self, text: str):
        self.toast.show_message(text)
        self._place_toast()
        self.statusBar().showMessage(text)

    def _visible_gene_names(self) -> list[str]:
        h = self._h
        if h is None:
            return []
        y0, y1 = sorted(h["ax_h"].get_ylim())
        lo, hi = max(0, math.ceil(y0)), min(h["n_g"] - 1, math.floor(y1))
        return [str(h["genes"][i]) for i in range(lo, hi + 1)]

    def _copy_visible_genes(self):
        names = self._visible_gene_names()
        if not names:
            return
        QGuiApplication.clipboard().setText("\n".join(names))
        self._say(f"{len(names)} gene names copied")

    def _copy_image(self):
        if self._data is None:
            return
        QGuiApplication.clipboard().setPixmap(self.canvas.grab())
        self._say("Image copied to the clipboard")

    def _export_figure(self):
        h = self._h
        if self._data is None or h is None:
            return
        vis = (h["cursor"].get_visible(), h["sel"].get_visible(), h["sel_l"].get_visible())
        for k in ("cursor", "sel", "sel_l"):             # niente evidenziazioni nella figura da pubblicare
            h[k].set_visible(False)
        self.canvas.draw()
        try:
            dlg = ExportDialog(self.hm)
            ok = dlg.exec()
        finally:
            for k, v in zip(("cursor", "sel", "sel_l"), vis):
                h[k].set_visible(v)
            self.canvas.draw_idle()
        if ok:
            self._say("Figure saved")

    def _export_table(self):
        if self._data is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save ordered table", "heatmap_ordered_table.csv", "CSV (*.csv)")
        if not path:
            return
        try:
            ordered_table(self._data).to_csv(path, index=False)
        except OSError as e:
            QMessageBox.critical(self, "Error", f"Unable to save the file: {e}")
            return
        self._say(f"Table saved to {path.replace(chr(92), '/').split('/')[-1]}")

    # ------------------------------------------------------------------ preferenze
    def _load_prefs(self):
        s = self._settings
        geo = s.value("geometry")
        if geo is not None:
            try:
                self.restoreGeometry(geo)
            except Exception:  # noqa: BLE001
                pass

        def combo(c: QComboBox, key: str):
            v = s.value(key)
            if isinstance(v, str) and c.findText(v) >= 0:
                c.setCurrentText(v)

        combo(self.c_mode, "gene_mode")
        combo(self.c_values, "values")
        combo(self.c_link, "linkage")
        combo(self.c_metric, "metric")
        combo(self.c_cols, "col_mode")
        combo(self.c_cmap, "cmap")
        for key, w in (("topn", self.c_topn), ("vlim", self.c_vlim)):
            try:
                w.setValue(type(w.value())(float(s.value(key))))
            except (TypeError, ValueError):
                pass
        for key, w in (("gene_dendro", self.c_gdendro), ("gene_labels", self.c_glabels)):
            v = s.value(key)
            if v is not None:
                w.setChecked(str(v).lower() in ("true", "1"))
        self.c_vlim.setEnabled(self.c_values.currentText() == VALUE_MODES[0])

    def _save_prefs(self):
        s = self._settings
        s.setValue("geometry", self.saveGeometry())
        s.setValue("gene_mode", self.c_mode.currentText())
        s.setValue("topn", self.c_topn.value())
        s.setValue("values", self.c_values.currentText())
        s.setValue("linkage", self.c_link.currentText())
        s.setValue("metric", self.c_metric.currentText())
        s.setValue("col_mode", self.c_cols.currentText())
        s.setValue("cmap", self.c_cmap.currentText())
        s.setValue("vlim", self.c_vlim.value())
        s.setValue("gene_dendro", self.c_gdendro.isChecked())
        s.setValue("gene_labels", self.c_glabels.isChecked())

    def closeEvent(self, e):
        self._save_prefs()
        self._t_compute.stop()
        self._t_render.stop()
        super().closeEvent(e)
