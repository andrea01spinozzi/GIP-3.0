import sys
import traceback
def main():
    try:
        import core_calcolo as engine
    except Exception as e:
        print("Critical error: unable to import core_calcolo.py:", e)
        traceback.print_exc()
        sys.exit(1)

    problems = engine.check_environment()
    if problems:
        print("Attention: the following environmental issues have been detected:")
        for p in problems:
            print(" - " + p)
        print("The app will launch anyway; you can correct the environment and try again from the GUI.\n")

    try:
        import gui_qt as gui
    except Exception as e:
        print("Critical error: unable to import gui_qt.py:", e)
        print("Verify that the Python dependencies are installed: run ./setup_mac.sh "
              "(or: pip install -r requirements.txt).")
        traceback.print_exc()
        sys.exit(1)

    gui.launch()


if __name__ == "__main__":
    main()

