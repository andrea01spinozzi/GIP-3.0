#!/bin/bash
# One-time setup for DEA Explorer on macOS (Intel or Apple Silicon).
set -e
cd "$(dirname "$0")"
echo "== DEA Explorer: macOS setup =="

# --- Python ---------------------------------------------------------------------------------
PY=""
for c in python3.12 python3.11 python3.10 python3; do
  for d in /opt/homebrew/bin /usr/local/bin /Library/Frameworks/Python.framework/Versions/Current/bin /usr/bin; do
    if [ -x "$d/$c" ] && "$d/$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)' 2>/dev/null; then PY="$d/$c"; break 2; fi
  done
done
if [ -z "$PY" ]; then
  echo "Python 3.9+ not found. Install it from https://www.python.org/downloads/macos/ (or: brew install python) and re-run."
  exit 1
fi
echo "Using Python: $PY ($("$PY" --version))"

if [ ! -d .venv ]; then "$PY" -m venv .venv; fi
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo "Python packages installed."

# --- R --------------------------------------------------------------------------------------
RS=""
for p in "$(command -v Rscript 2>/dev/null)" /Library/Frameworks/R.framework/Resources/bin/Rscript /opt/homebrew/bin/Rscript /usr/local/bin/Rscript /opt/local/bin/Rscript; do
  if [ -n "$p" ] && [ -x "$p" ]; then RS="$p"; break; fi
done
if [ -z "$RS" ]; then
  echo
  echo "R was NOT found. Install it from https://cran.r-project.org/bin/macosx/ (choose the arm64 build on"
  echo "Apple Silicon) or with 'brew install r'. Also run 'xcode-select --install' (needed to compile some packages)."
  echo "Then run this script again."
  exit 1
fi
echo "Using R: $RS"
read -r -p "Install / update the required R packages now? (can take 15-40 min the first time) [Y/n] " ans
if [[ ! "$ans" =~ ^[Nn] ]]; then
  "$RS" install_r_packages.R
fi
echo
echo "Setup finished. Start the app by double-clicking run_mac.command (or: ./run_mac.command)."
