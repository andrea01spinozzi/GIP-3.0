suppressWarnings(suppressMessages({
  ok_jsonlite <- requireNamespace("jsonlite", quietly = TRUE)
}))
if (!ok_jsonlite) {
  stop("The 'jsonlite' package is not installed. Run: install.packages('jsonlite')")
}
library(jsonlite)

`%||%` <- function(a, b) if (is.null(a) || (length(a) == 1 && is.na(a))) b else a

# --- Utility: locates the folder where this script lives -----------
.script_dir <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_flag <- "--file="
  hit <- grep(file_flag, cmd_args)
  if (length(hit) > 0) {
    return(dirname(normalizePath(sub(file_flag, "", cmd_args[hit]))))
  }
  return(getwd())
}

# --- Extracts ONLY the function definitions from DE_scheletro_FINALE.Rmd.
# Main sections (lines starting with a single "# N.") are loaded EXCEPT:
#   7 ("SIMULATION AND FULL TEST")  and  9 ("USAGE EXAMPLE"): demo code with hardcoded paths / objects.
# Section 8 (expression vs metadata plots) only defines functions, so it is loaded.
.SKIP_SECTIONS <- c(7L, 9L)

.load_core_functions <- function(core_path) {
  if (!file.exists(core_path)) {
    stop("File DE_scheletro_FINALE.Rmd not found at: ", core_path)
  }
  raw_lines <- readLines(core_path, warn = FALSE, encoding = "UTF-8")

  in_chunk <- FALSE
  skip_section <- FALSE
  code_lines <- character(0)

  for (ln in raw_lines) {
    trimmed <- trimws(ln)

    # Section headings are only looked for OUTSIDE code chunks (inside chunks "# 7." etc. are plain comments)
    if (!in_chunk) {
      m <- regmatches(trimmed, regexec("^#\\s*([0-9]+)\\.", trimmed))[[1]]
      if (length(m) == 2) skip_section <- as.integer(m[2]) %in% .SKIP_SECTIONS
    }

    if (grepl("^```\\{r", trimmed)) { in_chunk <- TRUE; next }
    if (in_chunk && trimmed == "```") { in_chunk <- FALSE; next }
    if (in_chunk && !skip_section) code_lines <- c(code_lines, ln)
  }

  if (length(code_lines) == 0) {
    stop("Could not extract any function from DE_scheletro_FINALE.Rmd: unexpected format.")
  }

  tmp_core <- tempfile(fileext = ".R")
  writeLines(code_lines, tmp_core, useBytes = TRUE)
  source(tmp_core, echo = FALSE, encoding = "UTF-8")  # locale-independent (Finder-launched apps have no UTF-8 locale)
}

# --- Writes an error in JSON format and exits with status != 0 -------------
.fail <- function(out_dir, msg) {
  err_path <- file.path(out_dir, "error.json")
  write(toJSON(list(error = msg), auto_unbox = TRUE), err_path)
  cat("ERROR: ", msg, "\n", sep = "")
  quit(status = 1)
}

# MAIN
args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 1) {
  stop("Usage: Rscript run_pipeline.R <config.json>")
}
config_path <- args[1]
if (!file.exists(config_path)) {
  stop("Configuration file not found: ", config_path)
}
cfg <- fromJSON(config_path)
out_dir <- cfg$out_dir
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

core_path <- cfg$core_path %||% file.path(.script_dir(), "DE_scheletro_FINALE.Rmd")

tryCatch({

  suppressWarnings(suppressMessages({
    .load_core_functions(core_path)
  }))

  # MODE 1: list_groups
  # Reads only the metadata and extracts the available groups, so the GUI can let the user choose them BEFORE launching the whole pipeline.
  if (cfg$mode == "list_groups") {

    metadata <- import_metadata(cfg$metadata_path,
                                 sample_col = cfg$sample_col,
                                 condition_col = cfg$condition_col)

    groups <- get_available_groups(metadata)
    n_per_group <- as.list(table(as.character(metadata$condition)))

    out <- list(
      groups = groups,
      counts = n_per_group,
      n_samples = nrow(metadata)
    )
    write(toJSON(out, auto_unbox = TRUE, pretty = TRUE),
          file.path(out_dir, "groups.json"))
    cat("OK\n")

  # MODE 2: run_dea
  # Runs the full pipeline (import -> DEA -> table -> GSEA), reusing EXACTLY the functions from DE_scheletro_FINALE.Rmd.
  } else if (cfg$mode == "run_dea") {

    is_micro <- identical(cfg$method, "Microarray")

    # Organism (Homo sapiens / Mus musculus / Rattus norvegicus / Danio rerio): drives ID -> symbol conversion
    # and the MSigDB gene sets. get_species_info() stops with a clear message if the species is not supported.
    species <- cfg$species %||% "Homo sapiens"
    get_species_info(species)
    message(">>> Species: ", species)

    # The low-expression filter is now configured through globals of the Rmd (section 1b):
    # the GUI value is the minimum TOTAL counts per gene.
    assign("FILTER_MIN_TOTAL_COUNTS", as.numeric(cfg$min_counts %||% 10), envir = globalenv())

    counts <- import_expression(cfg$counts_path,
                                 gene_col = cfg$gene_col,
                                 is_microarray = is_micro,
                                 species = species)
    metadata <- import_metadata(cfg$metadata_path,
                                 sample_col = cfg$sample_col,
                                 condition_col = cfg$condition_col)

    # --- Optional gene filter: keep ONLY the genes typed by the user (case-insensitive match on the gene symbols).
    gene_filter_active <- FALSE
    if (length(cfg$gene_list) > 0) {
      wanted <- unique(trimws(as.character(unlist(cfg$gene_list))))
      wanted <- wanted[nzchar(wanted)]
      hit <- match(toupper(wanted), toupper(rownames(counts)))
      not_found <- wanted[is.na(hit)]
      if (length(not_found) > 0) {
        message(">>> [Note] Genes not found in the dataset (ignored): ",
                paste(not_found, collapse = ", "))
      }
      hit <- unique(hit[!is.na(hit)])
      if (length(hit) < 2) {
        .fail(out_dir, paste0("At least 2 of the requested genes must be present in the dataset. ",
                              "Found: ", length(hit), "."))
      }
      counts <- counts[hit, , drop = FALSE]
      gene_filter_active <- TRUE
      message(">>> Analysis restricted to ", nrow(counts), " genes.")
    }

    # --- Exploratory PCA: we extract only the underlying data (p$data) and the axis labels so it can be redrawn interactively in Python.
    # With a single contrast, the PCA also uses only the 2 selected groups (with "pairwise_all" all groups are kept).
    pca_counts <- counts
    pca_meta <- metadata
    if (!isTRUE(cfg$pairwise_all) && length(cfg$contrast) == 2) {
      sel <- rownames(metadata)[as.character(metadata$condition) %in% as.character(cfg$contrast)]
      sel <- intersect(sel, colnames(counts))
      pca_counts <- counts[, sel, drop = FALSE]
      pca_meta <- metadata[sel, , drop = FALSE]
    }
    p_pca <- plot_universal_pca(pca_counts, pca_meta, title = "PCA of Count Data")
    write.csv(p_pca$data, file.path(out_dir, "pca_data.csv"), row.names = FALSE)
    write(toJSON(list(x_label = p_pca$labels$x, y_label = p_pca$labels$y),
                 auto_unbox = TRUE),
          file.path(out_dir, "pca_labels.json"))

    padj_cutoff <- cfg$padj_cutoff %||% 0.05
    gsea_category <- cfg$gsea_category %||% "H"
    gsea_subcategory <- cfg$gsea_subcategory %||% NULL
    lfc_cutoff <- cfg$lfc_cutoff %||% 1
    run_ora <- isTRUE(cfg$run_ora %||% TRUE)
    ora_direction <- cfg$ora_direction %||% "all"

    # The model is fitted ONCE (design ~ condition on all samples: identical to what each single contrast used to
    # re-fit) and then every contrast is extracted from it. The same fit gives the normalized matrix for the gene plots.
    if (!isTRUE(cfg$pairwise_all)) validate_contrast(metadata, as.character(cfg$contrast))
    model <- fit_dea_model(counts, metadata, method = cfg$method)

    # Normalized expression (log2 scale) of every gene in every sample: used by the "Gene counts" plots in the GUI.
    tryCatch({
      norm_mat <- prepare_normalized_matrix(model, norm = "norm_counts")
      scale_label <- attr(norm_mat, "scale_label") %||% "Expression (log2)"
      norm_df <- cbind(GeneID = rownames(norm_mat),
                       as.data.frame(round(as.matrix(norm_mat), 4), check.names = FALSE),
                       stringsAsFactors = FALSE)
      data.table::fwrite(norm_df, file.path(out_dir, "norm_matrix.csv"))
      write(toJSON(list(scale_label = scale_label), auto_unbox = TRUE), file.path(out_dir, "norm_meta.json"))
    }, error = function(e) {
      message(">>> [Note] Normalized matrix not exported (gene plots unavailable): ", conditionMessage(e))
    })

    run_one <- function(contrast, tag) {
      res_tbl <- extract_dea_results(model, contrast = contrast)
      write.csv(res_tbl, file.path(out_dir, paste0("res_tbl_", tag, ".csv")),
                row.names = FALSE)

      ranked <- generate_ranked_gene_table(res_tbl, padj_cutoff = padj_cutoff)
      write.csv(ranked, file.path(out_dir, paste0("ranked_", tag, ".csv")),
                row.names = FALSE)

      # With a user-defined gene list, ORA/GSEA are not meaningful (too few genes): they are skipped.
      if (gene_filter_active) {
        write(toJSON(list(available = FALSE, direction = cfg$ora_direction %||% "all",
                          note = "ORA/GSEA skipped: analysis restricted to a user-defined gene list."),
                     auto_unbox = TRUE),
              file.path(out_dir, paste0("ora_meta_", tag, ".json")))
        return(invisible(NULL))
      }

      # --- ORA (Over-Representation Analysis) ---
      # Same cutoffs (padj / log2FC) and same MSigDB category as the GSEA.
      if (run_ora) {
        ora_note <- NULL
        ora_res <- tryCatch({
          withCallingHandlers(
            run_ora_analysis(res_tbl, direction = ora_direction,
                             padj_cutoff = padj_cutoff, lfc_cutoff = lfc_cutoff,
                             category = gsea_category, subcategory = gsea_subcategory,
                             species = species),
            warning = function(w) {
              ora_note <<- conditionMessage(w)
              message(">>> [Note] ORA '", tag, "': ", conditionMessage(w))
              invokeRestart("muffleWarning")
            })
        }, error = function(e) {
          ora_note <<- conditionMessage(e)
          message(">>> [Note] ORA failed for '", tag, "': ", conditionMessage(e))
          NULL
        })

        ora_meta <- list(available = FALSE, direction = ora_direction, note = "")
        if (!is.null(ora_res) && nrow(ora_res) > 0) {
          ora_meta$available <- TRUE
          ora_meta$n_input_genes <- attr(ora_res, "n_input_genes")
          ora_meta$origin <- attr(ora_res, "origin")
          write.csv(as.data.frame(ora_res),
                    file.path(out_dir, paste0("ora_", tag, ".csv")), row.names = FALSE)
        } else {
          ora_meta$note <- ora_note %||% "No ORA results."
        }
        write(toJSON(ora_meta, auto_unbox = TRUE),
              file.path(out_dir, paste0("ora_meta_", tag, ".json")))
      }

      gsea_ok <- TRUE
      gsea_res <- tryCatch({
        run_gsea_analysis(res_tbl, category = gsea_category, subcategory = gsea_subcategory,
                          species = species)
      }, error = function(e) {
        message(">>> [Note] GSEA failed for '", tag, "': ", conditionMessage(e))
        gsea_ok <<- FALSE
        NULL
      })
      if (gsea_ok && !is.null(gsea_res)) {
        gsea_out <- as.data.frame(gsea_res)
        # leadingEdge is a list-column: we turn it into a string for the CSV
        if ("leadingEdge" %in% colnames(gsea_out)) {
          gsea_out$leadingEdge <- vapply(gsea_out$leadingEdge,
                                          function(x) paste(x, collapse = ";"),
                                          character(1))
        }
        write.csv(gsea_out, file.path(out_dir, paste0("gsea_", tag, ".csv")),
                  row.names = FALSE)
      }
      invisible(NULL)
    }

    if (isTRUE(cfg$pairwise_all)) {
      groups <- get_available_groups(metadata)
      if (length(groups) < 2) {
        .fail(out_dir, "At least 2 groups are needed for a pairwise comparison.")
      }
      pairs <- combn(groups, 2, simplify = FALSE)
      pair_tags <- character(0)
      contrast_info <- list()
      for (p in pairs) {
        tag <- paste(p[1], "vs", p[2], sep = "_")
        pair_tags <- c(pair_tags, tag)
        contrast_info[[length(contrast_info) + 1]] <-
          list(tag = tag, group_high = p[1], group_low = p[2])
        run_one(p, tag)
      }
      write(toJSON(list(pairs = pair_tags, contrasts = contrast_info), auto_unbox = TRUE),
            file.path(out_dir, "pairs.json"))
    } else {
      contrast <- as.character(cfg$contrast)
      # The tag now carries the real comparison (e.g. "Drug_vs_Control"), no longer "main".
      # contrast[1] = test group (numerator), contrast[2] = reference group (denominator).
      tag <- paste(contrast[1], "vs", contrast[2], sep = "_")
      run_one(contrast, tag)
      write(toJSON(list(pairs = tag,
                        contrasts = list(list(tag = tag, group_high = contrast[1],
                                              group_low = contrast[2]))),
                   auto_unbox = TRUE),
            file.path(out_dir, "pairs.json"))
    }

    cat("OK\n")

  } else {
    .fail(out_dir, paste0("Unrecognized mode: ", cfg$mode))
  }

}, error = function(e) {
  .fail(out_dir, conditionMessage(e))
})
